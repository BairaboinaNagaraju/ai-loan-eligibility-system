from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.database import engine, Base
from app.api import auth, predict, applications, dashboard

# Create SQLite tables on startup
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="AI Loan Eligibility Prediction System API",
    description="REST APIs for predicting loan eligibility, managing users, loan applications, and dashboards",
    version="1.0.0"
)

# Configure CORS for local development
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allows all origins in development
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Register routers
app.include_router(auth.router)
app.include_router(predict.router)
app.include_router(applications.router)
app.include_router(dashboard.router)

import os
from fastapi.staticfiles import StaticFiles

# Serve compiled frontend static files if folder exists (Production Container Mode)
static_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "static")
if os.path.exists(static_path):
    app.mount("/", StaticFiles(directory=static_path, html=True), name="static")
else:
    @app.get("/")
    def read_root():
        return {
            "status": "healthy",
            "message": "AI Loan Eligibility Prediction System API is running",
            "version": "1.0.0"
        }
