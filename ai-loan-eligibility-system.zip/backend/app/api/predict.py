from fastapi import APIRouter, Depends
from app.models.schemas import LoanApplicationCreate
from app.services.ml_service import ml_service

router = APIRouter(prefix="/api/predict", tags=["prediction"])

@router.post("")
def predict_loan_status(data: LoanApplicationCreate):
    prediction, confidence, explanation, recommendations = ml_service.predict(data)
    return {
        "prediction": prediction,
        "confidence_score": confidence,
        "explanation": explanation,
        "recommendations": recommendations
    }
