import json
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List, Optional
from app.database import get_db
from app.models.models import LoanApplication, User
from app.models.schemas import LoanApplicationCreate, LoanApplicationResponse
from app.api.auth import get_current_user
from app.services.ml_service import ml_service

router = APIRouter(prefix="/api/applications", tags=["applications"])

def db_to_schema(app_model: LoanApplication, db: Session) -> LoanApplicationResponse:
    # Safely load JSON strings
    try:
        explanation = json.loads(app_model.explanation) if app_model.explanation else []
    except Exception:
        explanation = [app_model.explanation] if app_model.explanation else []
        
    try:
        recommendations = json.loads(app_model.recommendations) if app_model.recommendations else []
    except Exception:
        recommendations = [app_model.recommendations] if app_model.recommendations else []

    # Get applicant name for display
    applicant_name = "Unknown"
    user_rec = db.query(User).filter(User.id == app_model.user_id).first()
    if user_rec:
        applicant_name = user_rec.full_name or user_rec.username

    return LoanApplicationResponse(
        id=app_model.id,
        user_id=app_model.user_id,
        gender=app_model.gender,
        married=app_model.married,
        dependents=app_model.dependents,
        education=app_model.education,
        self_employed=app_model.self_employed,
        applicant_income=app_model.applicant_income,
        coapplicant_income=app_model.coapplicant_income,
        loan_amount=app_model.loan_amount,
        loan_amount_term=app_model.loan_amount_term,
        credit_history=app_model.credit_history,
        property_area=app_model.property_area,
        prediction=app_model.prediction,
        confidence_score=app_model.confidence_score,
        explanation=explanation,
        recommendations=recommendations,
        status=app_model.status,
        created_at=app_model.created_at,
        applicant_name=applicant_name
    )

@router.post("", response_model=LoanApplicationResponse)
def create_application(data: LoanApplicationCreate, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    # Run the prediction
    prediction, confidence, explanation, recommendations = ml_service.predict(data)
    
    # Create the model instance
    new_app = LoanApplication(
        user_id=current_user.id,
        gender=data.gender,
        married=data.married,
        dependents=data.dependents,
        education=data.education,
        self_employed=data.self_employed,
        applicant_income=data.applicant_income,
        coapplicant_income=data.coapplicant_income,
        loan_amount=data.loan_amount,
        loan_amount_term=data.loan_amount_term,
        credit_history=data.credit_history,
        property_area=data.property_area,
        prediction=prediction,
        confidence_score=confidence,
        explanation=json.dumps(explanation),
        recommendations=json.dumps(recommendations),
        status=prediction # Automatically sets initial status to prediction (Approved or Rejected)
    )
    
    db.add(new_app)
    db.commit()
    db.refresh(new_app)
    
    return db_to_schema(new_app, db)

@router.get("", response_model=List[LoanApplicationResponse])
def get_applications(
    search: Optional[str] = None,
    status_filter: Optional[str] = None,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    query = db.query(LoanApplication)
    
    # If not admin, restrict to own applications
    if not current_user.is_admin:
        query = query.filter(LoanApplication.user_id == current_user.id)
    else:
        # Admin can search applicant name
        if search:
            # Join with users to search by username or full name
            query = query.join(User).filter(
                (User.username.contains(search)) | 
                (User.full_name.contains(search)) |
                (LoanApplication.property_area.contains(search))
            )
            
    if status_filter:
        query = query.filter(LoanApplication.status == status_filter)
        
    apps = query.order_by(LoanApplication.created_at.desc()).all()
    return [db_to_schema(app, db) for app in apps]

@router.delete("/{app_id}")
def delete_application(app_id: int, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    app_model = db.query(LoanApplication).filter(LoanApplication.id == app_id).first()
    if not app_model:
        raise HTTPException(status_code=404, detail="Application not found")
        
    # Check permissions
    if not current_user.is_admin and app_model.user_id != current_user.id:
        raise HTTPException(
            status_code=403,
            detail="Not authorized to delete this application"
        )
        
    db.delete(app_model)
    db.commit()
    return {"message": "Application deleted successfully", "id": app_id}
