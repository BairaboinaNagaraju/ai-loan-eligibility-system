from pydantic import BaseModel, EmailStr, Field
from typing import List, Optional, Union
from datetime import datetime

# --- Authentication Schemas ---

class UserCreate(BaseModel):
    username: str = Field(..., min_length=3, max_length=50)
    email: EmailStr
    full_name: Optional[str] = None
    password: str = Field(..., min_length=6)

class UserLogin(BaseModel):
    username: str
    password: str

class UserResponse(BaseModel):
    id: int
    username: str
    email: EmailStr
    full_name: Optional[str] = None
    is_admin: bool
    created_at: datetime

    class Config:
        from_attributes = True

class UserUpdate(BaseModel):
    email: Optional[EmailStr] = None
    full_name: Optional[str] = None
    password: Optional[str] = None

class Token(BaseModel):
    access_token: str
    token_type: str
    user: UserResponse

class TokenData(BaseModel):
    username: Optional[str] = None


# --- Loan Application & Prediction Schemas ---

class LoanApplicationCreate(BaseModel):
    gender: str = Field(..., description="Male or Female")
    married: str = Field(..., description="Yes or No")
    dependents: str = Field(..., description="0, 1, 2, or 3+")
    education: str = Field(..., description="Graduate or Not Graduate")
    self_employed: str = Field(..., description="Yes or No")
    applicant_income: float = Field(..., ge=0, description="Applicant income in USD")
    coapplicant_income: float = Field(..., ge=0, description="Co-applicant income in USD")
    loan_amount: float = Field(..., ge=0, description="Loan amount in thousands")
    loan_amount_term: float = Field(..., ge=0, description="Term in days (e.g. 360)")
    credit_history: float = Field(..., description="1.0 for clean history, 0.0 for bad history")
    property_area: str = Field(..., description="Urban, Semiurban, or Rural")

class LoanApplicationResponse(BaseModel):
    id: int
    user_id: int
    gender: str
    married: str
    dependents: str
    education: str
    self_employed: str
    applicant_income: float
    coapplicant_income: float
    loan_amount: float
    loan_amount_term: float
    credit_history: float
    property_area: str
    prediction: str
    confidence_score: float
    explanation: Optional[List[str]] = []
    recommendations: Optional[List[str]] = []
    status: str
    created_at: datetime
    applicant_name: Optional[str] = None  # Loaded dynamically in admin views

    class Config:
        from_attributes = True


# --- Dashboard Stats Schemas ---

class RecentApplicationItem(BaseModel):
    id: int
    created_at: datetime
    loan_amount: float
    status: str
    prediction: str

class DashboardStats(BaseModel):
    total_applications: int
    approved_loans: int
    rejected_loans: int
    approval_rate: float
    recent_applications: List[RecentApplicationItem]
    # Charts data
    loan_trends: List[dict]         # [{month: "Jan", approved: 5, rejected: 2}]
    income_distribution: List[dict] # [{range: "0-5k", count: 12}]
    property_distribution: List[dict] # [{area: "Urban", count: 20}]
    credit_history_comparison: List[dict] # [{history: "Clean", approved: 30, rejected: 2}]

class AdminDashboardStats(BaseModel):
    total_users: int
    total_applications: int
    approved_loans: int
    rejected_loans: int
    approval_rate: float
    applications_by_month: List[dict]
    model_accuracy: float
    active_model: str
