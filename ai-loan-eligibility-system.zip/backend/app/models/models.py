from sqlalchemy import Column, Integer, String, Float, Boolean, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from app.database import Base

class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String, unique=True, index=True, nullable=False)
    email = Column(String, unique=True, index=True, nullable=False)
    full_name = Column(String, nullable=True)
    hashed_password = Column(String, nullable=False)
    is_admin = Column(Boolean, default=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    applications = relationship("LoanApplication", back_populates="user", cascade="all, delete-orphan")

class LoanApplication(Base):
    __tablename__ = "loan_applications"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    
    # Kaggle features
    gender = Column(String, nullable=False)
    married = Column(String, nullable=False)
    dependents = Column(String, nullable=False)
    education = Column(String, nullable=False)
    self_employed = Column(String, nullable=False)
    applicant_income = Column(Float, nullable=False)
    coapplicant_income = Column(Float, nullable=False)
    loan_amount = Column(Float, nullable=False)
    loan_amount_term = Column(Float, nullable=False)
    credit_history = Column(Float, nullable=False)
    property_area = Column(String, nullable=False)
    
    # Prediction details
    prediction = Column(String, nullable=False)  # 'Approved' or 'Rejected'
    confidence_score = Column(Float, nullable=False)
    explanation = Column(String, nullable=True)  # JSON serialized array of strings
    recommendations = Column(String, nullable=True)  # JSON serialized array of strings
    
    status = Column(String, default="Pending")  # 'Pending', 'Approved', 'Rejected'
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    user = relationship("User", back_populates="applications")
