import os
import joblib
import pandas as pd
import numpy as np
from typing import Dict, Any, List, Tuple
from app.models.schemas import LoanApplicationCreate

MODEL_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),
    "models",
    "best_model.joblib"
)

class MLService:
    def __init__(self):
        self.model = None
        self.feature_names = [
            "Gender", "Married", "Dependents", "Education", "Self_Employed",
            "ApplicantIncome", "CoapplicantIncome", "LoanAmount",
            "Loan_Amount_Term", "Credit_History", "Property_Area"
        ]
        self.load_model()

    def load_model(self):
        if os.path.exists(MODEL_PATH):
            try:
                self.model = joblib.load(MODEL_PATH)
                print(f"Successfully loaded model from {MODEL_PATH}")
            except Exception as e:
                print(f"Error loading model from {MODEL_PATH}: {e}")
                self.model = None
        else:
            print(f"Model file not found at {MODEL_PATH}. Using heuristic fallback.")
            self.model = None

    def predict(self, data: LoanApplicationCreate) -> Tuple[str, float, List[str], List[str]]:
        # If model is loaded, predict using the model pipeline
        if self.model is not None:
            try:
                # Prepare DataFrame
                df = pd.DataFrame([{
                    "Gender": data.gender,
                    "Married": data.married,
                    "Dependents": str(data.dependents),
                    "Education": data.education,
                    "Self_Employed": data.self_employed,
                    "ApplicantIncome": float(data.applicant_income),
                    "CoapplicantIncome": float(data.coapplicant_income),
                    "LoanAmount": float(data.loan_amount),
                    "Loan_Amount_Term": float(data.loan_amount_term),
                    "Credit_History": float(data.credit_history),
                    "Property_Area": data.property_area
                }])
                
                # Model predict & predict_proba
                pred = self.model.predict(df)[0]
                probs = self.model.predict_proba(df)[0]
                
                # Check target labels mapping
                # Standard training target: Y=1, N=0.
                if pred == 1 or str(pred).upper() == 'Y':
                    prediction = "Approved"
                    confidence = float(probs[1] if len(probs) > 1 else 0.85)
                else:
                    prediction = "Rejected"
                    confidence = float(probs[0] if len(probs) > 1 else 0.85)
                
                explanation, recommendations = self._generate_xai(data, prediction)
                return prediction, confidence, explanation, recommendations
            except Exception as e:
                print(f"Model prediction failed: {e}. Falling back to heuristic.")
        
        # Heuristic fallback if model not loaded or error occurs
        return self._predict_heuristic(data)

    def _predict_heuristic(self, data: LoanApplicationCreate) -> Tuple[str, float, List[str], List[str]]:
        # Heuristics derived from the Kaggle dataset:
        # 1. Credit History is the single most important factor. If Credit_History == 0, rejection is extremely likely.
        # 2. Total Income vs Loan Amount (Debt-to-Income). Standard guideline: Monthly Loan Payment should be <= 40% of income.
        #    Assuming term is in days, convert term to months. E.g. 360 days = 12 months.
        #    LoanAmount is in thousands (e.g. 100 means $100,000).
        #    ApplicantIncome & CoapplicantIncome are monthly.
        
        total_monthly_income = data.applicant_income + data.coapplicant_income
        loan_amount_dollars = data.loan_amount * 1000
        term_months = (data.loan_amount_term / 30.0) if data.loan_amount_term > 0 else 12.0
        
        # Simple interest rate of 8% for estimation
        annual_rate = 0.08
        monthly_rate = annual_rate / 12.0
        
        # Calculate approximate monthly payment (EMI)
        if total_monthly_income <= 0:
            emi = loan_amount_dollars / term_months
        else:
            emi = (loan_amount_dollars * monthly_rate * ((1 + monthly_rate)**term_months)) / (((1 + monthly_rate)**term_months) - 1) if monthly_rate > 0 else (loan_amount_dollars / term_months)
            
        debt_to_income = emi / total_monthly_income if total_monthly_income > 0 else 99.0
        
        # Credit history score
        credit_history = float(data.credit_history)
        
        # Logic structure
        score = 0.0
        if credit_history == 1.0:
            score += 0.65
        else:
            score -= 0.30
            
        if debt_to_income <= 0.30:
            score += 0.20
        elif debt_to_income <= 0.45:
            score += 0.10
        else:
            score -= 0.15
            
        if data.education == "Graduate":
            score += 0.05
            
        if data.property_area in ["Urban", "Semiurban"]:
            score += 0.05
            
        # Bound score between 0.1 and 0.99
        prob = 1.0 / (1.0 + np.exp(-score * 4)) # sigmoid scale
        
        if prob >= 0.50:
            prediction = "Approved"
            confidence = float(prob)
        else:
            prediction = "Rejected"
            confidence = float(1.0 - prob)
            
        explanation, recommendations = self._generate_xai(data, prediction)
        return prediction, confidence, explanation, recommendations

    def _generate_xai(self, data: LoanApplicationCreate, prediction: str) -> Tuple[List[str], List[str]]:
        explanation = []
        recommendations = []
        
        total_income = data.applicant_income + data.coapplicant_income
        loan_amount_dollars = data.loan_amount * 1000
        income_to_loan = (total_income * 12) / loan_amount_dollars if loan_amount_dollars > 0 else 99.0
        
        if prediction == "Approved":
            # Add positive factors
            if float(data.credit_history) == 1.0:
                explanation.append("Excellent Credit History: A consistent track record of timely credit payments.")
            if income_to_loan > 0.4:
                explanation.append("Strong Income-to-Loan Ratio: Monthly income supports the requested loan amount.")
            if data.coapplicant_income > 0:
                explanation.append("Co-applicant Income Support: Additional financial backing lowers overall risk.")
            if data.education == "Graduate":
                explanation.append("Academic Credentials: High educational background correlates with job stability.")
            if data.property_area == "Semiurban":
                explanation.append("Favorable Property Area: Semi-urban location offers high liquidity and stable valuation.")
            elif data.property_area == "Urban":
                explanation.append("Premium Property Location: Urban setting ensures strong underlying asset value.")
            
            # Simple fallback explanation if empty
            if not explanation:
                explanation.append("Balanced Application: Satisfies all baseline credit requirements.")
                
        else:
            # Add reasons for rejection
            if float(data.credit_history) == 0.0:
                explanation.append("Unfavorable Credit History: Lacks active clean credit history or records delayed payments.")
                recommendations.append("Build/improve your credit history by paying off outstanding bills and micro-loans on time.")
                
            if income_to_loan < 0.25:
                explanation.append("High Debt-to-Income Ratio: Requested loan amount exceeds threshold relative to total income.")
                recommendations.append("Reduce the requested loan amount or select a longer term to reduce monthly EMI requirements.")
                recommendations.append("Increase downpayment or add a co-applicant with a stable income source.")
                
            if total_income < 3000:
                explanation.append("Low Monthly Income Base: Current earnings are below standard financial cushions.")
                recommendations.append("Wait to apply until income base increases or list secondary income streams.")
                
            if data.self_employed == "Yes" and data.applicant_income < 4000:
                explanation.append("Self-Employed Risk Profile: Income volatility not fully offset by current revenue level.")
                recommendations.append("Provide additional profit-and-loss statements or collateral security options.")
                
            if data.property_area == "Rural":
                explanation.append("Suburban/Rural Valuation Risk: Property area has lower liquidity and property market demand.")
                recommendations.append("Apply with a higher downpayment to reduce the loan-to-value ratio.")
                
            if not explanation:
                explanation.append("Marginal Credit Metrics: Underwriter requirements not fully met.")
                recommendations.append("Consult our local bank branch or representative for custom credit line packages.")
                
        return explanation, recommendations

ml_service = MLService()
