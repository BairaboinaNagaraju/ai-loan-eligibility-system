import os
import json
import urllib.request
import pandas as pd
import numpy as np
import joblib
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score

# Classifiers
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.svm import SVC

# XGBoost
try:
    from xgboost import XGBClassifier
    XGB_AVAILABLE = True
except ImportError:
    XGB_AVAILABLE = False

DATASET_URL = "https://raw.githubusercontent.com/shrikant-temburwar/Loan-Prediction-Dataset/master/train.csv"

# Absolute paths
ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATASET_DIR = os.path.join(ROOT_DIR, "dataset")
MODELS_DIR = os.path.join(ROOT_DIR, "models")

os.makedirs(DATASET_DIR, exist_ok=True)
os.makedirs(MODELS_DIR, exist_ok=True)

CSV_PATH = os.path.join(DATASET_DIR, "loan_train.csv")

def download_or_generate_dataset():
    """Downloads the standard Kaggle dataset, or generates high-fidelity simulated data if offline."""
    print("Attempting to fetch dataset...")
    try:
        import socket
        socket.setdefaulttimeout(4.0)
        with urllib.request.urlopen(DATASET_URL, timeout=4.0) as response:
            with open(CSV_PATH, "wb") as f:
                f.write(response.read())
        print(f"Dataset successfully downloaded and saved to {CSV_PATH}")
        df = pd.read_csv(CSV_PATH)
        return df
    except Exception as e:
        print(f"Failed to download dataset: {e}. Generating simulated high-fidelity data...")
        
        # Seed for reproducibility
        np.random.seed(42)
        size = 614 # Matches original Kaggle train.csv row count
        
        genders = np.random.choice(["Male", "Female"], size=size, p=[0.81, 0.19])
        married = np.random.choice(["Yes", "No"], size=size, p=[0.65, 0.35])
        dependents = np.random.choice(["0", "1", "2", "3+"], size=size, p=[0.57, 0.17, 0.17, 0.09])
        education = np.random.choice(["Graduate", "Not Graduate"], size=size, p=[0.78, 0.22])
        self_employed = np.random.choice(["Yes", "No"], size=size, p=[0.14, 0.86])
        
        # Lognormal income distributions
        app_income = np.random.lognormal(mean=8.4, sigma=0.6, size=size).astype(int)
        co_income = np.random.exponential(scale=1600, size=size).astype(int)
        # Set some co-applicants to zero income (~45% have 0 co-applicant income)
        co_income[np.random.choice([True, False], size=size, p=[0.45, 0.55])] = 0
        
        # Loan Amount in thousands (e.g. 146 means $146,000)
        loan_amount = np.random.lognormal(mean=4.8, sigma=0.4, size=size).astype(int)
        # Loan terms: mostly 360 days (30 years)
        loan_term = np.random.choice([360, 180, 240, 480, 120, 84, 60], size=size, p=[0.85, 0.07, 0.03, 0.02, 0.01, 0.01, 0.01])
        
        # Credit history (1.0 or 0.0)
        credit_history = np.random.choice([1.0, 0.0], size=size, p=[0.84, 0.16])
        property_area = np.random.choice(["Urban", "Semiurban", "Rural"], size=size, p=[0.33, 0.38, 0.29])
        
        # Target probability calculation (highly dependent on Credit_History)
        # If Credit_History == 1.0, ~80% chance of Y.
        # If Credit_History == 0.0, ~90% chance of N.
        # Modified by debt-to-income and property area
        loan_status = []
        for i in range(size):
            p_approve = 0.05
            if credit_history[i] == 1.0:
                p_approve += 0.70
            if property_area[i] == "Semiurban":
                p_approve += 0.08
            elif property_area[i] == "Urban":
                p_approve += 0.03
                
            total_inc = app_income[i] + co_income[i]
            ratio = (loan_amount[i] * 1000) / (total_inc * 12) if total_inc > 0 else 99
            if ratio < 0.20:
                p_approve += 0.10
            elif ratio > 0.45:
                p_approve -= 0.20
                
            p_approve = np.clip(p_approve, 0.01, 0.99)
            status = "Y" if np.random.rand() < p_approve else "N"
            loan_status.append(status)
            
        # Introduce some missing values (similar to original dataset)
        genders = [g if np.random.rand() > 0.02 else np.nan for g in genders]
        married = [m if np.random.rand() > 0.01 else np.nan for m in married]
        dependents = [d if np.random.rand() > 0.02 else np.nan for d in dependents]
        self_employed = [s if np.random.rand() > 0.05 else np.nan for s in self_employed]
        loan_amount = [float(la) if np.random.rand() > 0.03 else np.nan for la in loan_amount]
        loan_term = [float(lt) if np.random.rand() > 0.02 else np.nan for lt in loan_term]
        credit_history = [float(ch) if np.random.rand() > 0.08 else np.nan for ch in credit_history]

        df = pd.DataFrame({
            "Loan_ID": [f"LP00{1000+i}" for i in range(size)],
            "Gender": genders,
            "Married": married,
            "Dependents": dependents,
            "Education": education,
            "Self_Employed": self_employed,
            "ApplicantIncome": app_income,
            "CoapplicantIncome": co_income,
            "LoanAmount": loan_amount,
            "Loan_Amount_Term": loan_term,
            "Credit_History": credit_history,
            "Property_Area": property_area,
            "Loan_Status": loan_status
        })
        
        df.to_csv(CSV_PATH, index=False)
        print(f"Simulated dataset saved to {CSV_PATH}")
        return df

def train_and_evaluate():
    # Load data
    df = download_or_generate_dataset()
    
    # Drop Loan_ID
    if "Loan_ID" in df.columns:
        df = df.drop(columns=["Loan_ID"])
        
    # Split features and target
    X = df.drop(columns=["Loan_Status"])
    y = df["Loan_Status"].map({"Y": 1, "N": 0})
    
    # Train-test split
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
    
    # Feature columns grouping
    num_features = ["ApplicantIncome", "CoapplicantIncome", "LoanAmount", "Loan_Amount_Term", "Credit_History"]
    cat_features = ["Gender", "Married", "Dependents", "Education", "Self_Employed", "Property_Area"]
    
    # Building pipeline preprocessor
    num_transformer = Pipeline(steps=[
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler())
    ])
    
    cat_transformer = Pipeline(steps=[
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("onehot", OneHotEncoder(handle_unknown="ignore", sparse_output=False))
    ])
    
    preprocessor = ColumnTransformer(transformers=[
        ("num", num_transformer, num_features),
        ("cat", cat_transformer, cat_features)
    ])
    
    # Define models
    models = {
        "Logistic Regression": LogisticRegression(random_state=42, max_iter=1000),
        "Decision Tree": DecisionTreeClassifier(random_state=42, max_depth=5),
        "Random Forest": RandomForestClassifier(random_state=42, n_estimators=100, max_depth=6),
        "Gradient Boosting": GradientBoostingClassifier(random_state=42, n_estimators=100, learning_rate=0.05, max_depth=4),
        "SVM": SVC(random_state=42, probability=True, C=1.0, kernel="rbf")
    }
    
    if XGB_AVAILABLE:
        models["XGBoost"] = XGBClassifier(random_state=42, n_estimators=100, max_depth=4, learning_rate=0.05, eval_metric="logloss")
        
    best_f1 = 0
    best_model_name = ""
    best_pipeline = None
    results = {}
    
    print("\nTraining and evaluating models...")
    print("-" * 80)
    print(f"{'Model':<25} | {'Accuracy':<8} | {'Precision':<9} | {'Recall':<6} | {'F1-Score':<8} | {'ROC AUC':<7}")
    print("-" * 80)
    
    for name, clf in models.items():
        # Create a pipeline with the preprocessor and the classifier
        pipeline = Pipeline(steps=[
            ("preprocessor", preprocessor),
            ("classifier", clf)
        ])
        
        # Train model
        pipeline.fit(X_train, y_train)
        
        # Predict
        y_pred = pipeline.predict(X_test)
        y_probs = pipeline.predict_proba(X_test)[:, 1]
        
        # Metrics
        acc = accuracy_score(y_test, y_pred)
        prec = precision_score(y_test, y_pred)
        rec = recall_score(y_test, y_pred)
        f1 = f1_score(y_test, y_pred)
        auc = roc_auc_score(y_test, y_probs)
        
        results[name] = {
            "accuracy": float(acc),
            "precision": float(prec),
            "recall": float(rec),
            "f1_score": float(f1),
            "roc_auc": float(auc)
        }
        
        print(f"{name:<25} | {acc:.4f}   | {prec:.4f}    | {rec:.4f} | {f1:.4f}   | {auc:.4f}")
        
        # We select best model based on F1-Score (balances precision and recall)
        if f1 > best_f1:
            best_f1 = f1
            best_model_name = name
            best_pipeline = pipeline

    print("-" * 80)
    print(f"Best Model: {best_model_name} with F1-Score: {best_f1:.4f}")
    
    # Save the best model
    best_model_path = os.path.join(MODELS_DIR, "best_model.joblib")
    joblib.dump(best_pipeline, best_model_path)
    print(f"Saved best model pipeline to {best_model_path}")
    
    # Save metrics JSON
    metrics_path = os.path.join(MODELS_DIR, "model_metrics.json")
    metrics_info = {
        "model_name": best_model_name,
        "accuracy": results[best_model_name]["accuracy"],
        "precision": results[best_model_name]["precision"],
        "recall": results[best_model_name]["recall"],
        "f1_score": results[best_model_name]["f1_score"],
        "roc_auc": results[best_model_name]["roc_auc"],
        "trained_at": pd.Timestamp.now().isoformat(),
        "all_models_metrics": results
    }
    with open(metrics_path, "w") as f:
        json.dump(metrics_info, f, indent=4)
    print(f"Saved evaluation metrics to {metrics_path}")

if __name__ == "__main__":
    train_and_evaluate()
