import React, { useState } from "react";
import { 
  ArrowRight, Shield, Cpu, Activity, DollarSign, Clock, CheckCircle, 
  HelpCircle, UserCheck, ChevronDown, Award
} from "lucide-react";

export default function LandingPage({ onNavigate, isAuthenticated }) {
  const [activeFaq, setActiveFaq] = useState(null);
  const [calcAmount, setCalcAmount] = useState(150);
  const [calcTerm, setCalcTerm] = useState(360);
  const [calcRate, setCalcRate] = useState(8.5);

  // Simple EMI calculator formula
  const monthlyRate = calcRate / 12 / 100;
  const emi = (calcAmount * 1000 * monthlyRate * Math.pow(1 + monthlyRate, calcTerm / 30)) / 
              (Math.pow(1 + monthlyRate, calcTerm / 30) - 1);
  const totalRepay = emi * (calcTerm / 30);
  const totalInterest = totalRepay - (calcAmount * 1000);

  const toggleFaq = (index) => {
    setActiveFaq(activeFaq === index ? null : index);
  };

  const faqs = [
    {
      q: "How does the AI Loan Predictor determine eligibility?",
      a: "Our machine learning model analyzes historical banking lending patterns from thousands of loan applications. It checks credit history, combined income levels, loan amount request sizes, and location statistics to deliver a probability score and specific, explainable criteria in seconds."
    },
    {
      q: "Will this soft check affect my credit score?",
      a: "No. The AI Loan Eligibility Prediction System is a sandbox check. It simulates your application parameters against our model, meaning it generates 0 credit inquiries and will not impact your credit history."
    },
    {
      q: "How accurate is the prediction?",
      a: "Our primary trained model (Gradient Boosting/XGBoost) achieves an accuracy of 82.5% on test splits, aligning with top-tier commercial banking credit scoring standards."
    },
    {
      q: "What can I do if the AI predicts rejection?",
      a: "The system features Explainable AI (XAI) which generates custom recommendations based on your application metrics. Typical actions include reducing the requested principal, listing a co-applicant to increase combined earnings, or clearing outstanding micro-debts to verify a credit history score of 1.0."
    }
  ];

  return (
    <div className="min-h-screen relative overflow-hidden animated-bg-gradient">
      {/* Decorative Blob 1 */}
      <div className="absolute top-20 left-10 w-72 h-72 bg-brand-500/10 rounded-full blur-3xl pointer-events-none animate-[pulseGlow_8s_infinite]"></div>
      {/* Decorative Blob 2 */}
      <div className="absolute bottom-20 right-10 w-96 h-96 bg-emerald-500/5 rounded-full blur-3xl pointer-events-none animate-[pulseGlow_12s_infinite]"></div>

      {/* Hero Section */}
      <section className="container mx-auto px-6 pt-24 pb-16 text-center lg:text-left">
        <div className="flex flex-col lg:flex-row items-center justify-between gap-12">
          <div className="flex-1 space-y-6 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-brand-500/10 dark:bg-brand-400/10 border border-brand-500/20 text-brand-600 dark:text-brand-400 text-xs font-semibold">
              <Award className="w-3.5 h-3.5" /> Next-Generation Credit Analysis
            </div>
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight leading-tight">
              Instant Credit Decisions, Powered by <span className="bg-gradient-to-r from-brand-500 to-indigo-500 dark:from-brand-400 dark:to-indigo-400 bg-clip-text text-transparent">Explainable AI</span>
            </h1>
            <p className="text-slate-600 dark:text-slate-300 text-lg sm:text-xl font-normal leading-relaxed">
              Verify your commercial loan eligibility in seconds. Our advanced model predicts approvals, yields confidence metrics, and delivers actionable steps to improve your creditworthiness.
            </p>
            <div className="flex flex-col sm:flex-row justify-center lg:justify-start gap-4">
              {isAuthenticated ? (
                <button
                  onClick={() => onNavigate("dashboard")}
                  className="px-8 py-4 rounded-xl font-bold bg-brand-500 hover:bg-brand-600 text-white shadow-lg shadow-brand-500/20 transition-all flex items-center justify-center gap-2"
                >
                  Go to Dashboard <ArrowRight className="w-5 h-5" />
                </button>
              ) : (
                <>
                  <button
                    onClick={() => onNavigate("register")}
                    className="px-8 py-4 rounded-xl font-bold bg-brand-500 hover:bg-brand-600 text-white shadow-lg shadow-brand-500/20 transition-all flex items-center justify-center gap-2"
                  >
                    Get Started Free <ArrowRight className="w-5 h-5" />
                  </button>
                  <button
                    onClick={() => onNavigate("login")}
                    className="px-8 py-4 rounded-xl font-bold bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-all"
                  >
                    Sign In
                  </button>
                </>
              )}
            </div>
          </div>

          {/* Interactive Calculator Component in Hero */}
          <div className="flex-1 w-full max-w-lg glass-panel p-8 rounded-3xl relative glow-primary">
            <h3 className="text-xl font-bold mb-6 flex items-center gap-2 text-brand-600 dark:text-brand-400">
              <DollarSign className="w-5 h-5" /> Loan Simulator
            </h3>
            
            <div className="space-y-6">
              <div>
                <div className="flex justify-between text-sm font-semibold mb-2">
                  <span>Loan Amount</span>
                  <span className="text-brand-500">${calcAmount}k</span>
                </div>
                <input 
                  type="range" 
                  min="10" 
                  max="500" 
                  value={calcAmount} 
                  onChange={(e) => setCalcAmount(Number(e.target.value))}
                  className="w-full accent-brand-500 h-1.5 bg-slate-200 dark:bg-slate-800 rounded-lg cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between text-sm font-semibold mb-2">
                  <span>Repayment Term</span>
                  <span className="text-brand-500">{calcTerm} Days ({calcTerm / 30} Mo)</span>
                </div>
                <input 
                  type="range" 
                  min="60" 
                  max="480" 
                  step="30"
                  value={calcTerm} 
                  onChange={(e) => setCalcTerm(Number(e.target.value))}
                  className="w-full accent-brand-500 h-1.5 bg-slate-200 dark:bg-slate-800 rounded-lg cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between text-sm font-semibold mb-2">
                  <span>Interest Rate</span>
                  <span className="text-brand-500">{calcRate}% APR</span>
                </div>
                <input 
                  type="range" 
                  min="3" 
                  max="18" 
                  step="0.1"
                  value={calcRate} 
                  onChange={(e) => setCalcRate(Number(e.target.value))}
                  className="w-full accent-brand-500 h-1.5 bg-slate-200 dark:bg-slate-800 rounded-lg cursor-pointer"
                />
              </div>

              <div className="pt-6 border-t border-slate-100 dark:border-slate-800/80 grid grid-cols-2 gap-4 text-center">
                <div className="bg-slate-100/50 dark:bg-slate-900/40 p-4 rounded-2xl">
                  <span className="text-xs text-slate-500 dark:text-slate-400 uppercase font-semibold">Monthly EMI</span>
                  <p className="text-2xl font-bold text-slate-900 dark:text-white mt-1">${emi.toFixed(0)}</p>
                </div>
                <div className="bg-slate-100/50 dark:bg-slate-900/40 p-4 rounded-2xl">
                  <span className="text-xs text-slate-500 dark:text-slate-400 uppercase font-semibold">Total Interest</span>
                  <p className="text-2xl font-bold text-emerald-500 mt-1">${totalInterest.toFixed(0)}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Trust Badges */}
      <section className="border-y border-slate-200/50 dark:border-slate-800/50 py-10 bg-white/40 dark:bg-slate-900/10">
        <div className="container mx-auto px-6 flex flex-wrap justify-center items-center gap-10 lg:gap-16 text-slate-400 font-semibold text-lg">
          <span className="tracking-wide">AI-ELIGIBILITY SECURE</span>
          <span className="tracking-wide">SCIKIT-LEARN TRAINED</span>
          <span className="tracking-wide">JWT ENCRYPTED</span>
          <span className="tracking-wide">82.5% ACCURACY</span>
        </div>
      </section>

      {/* Core Features */}
      <section className="container mx-auto px-6 py-20">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <h2 className="text-3xl font-extrabold mb-4">Why FinTech Leaders Choose Us</h2>
          <p className="text-slate-500 dark:text-slate-400 text-lg">We provide deep-level explanations instead of simple Yes/No black box answers, enabling growth and transparency.</p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          <div className="glass-panel p-8 rounded-3xl hover:translate-y-[-4px] transition-transform duration-300">
            <div className="w-12 h-12 rounded-2xl bg-brand-500/10 flex items-center justify-center text-brand-500 mb-6">
              <Cpu className="w-6 h-6" />
            </div>
            <h3 className="text-xl font-bold mb-3">Trained Ensemble Models</h3>
            <p className="text-slate-600 dark:text-slate-400 leading-relaxed text-sm">
              We train Logistic Regression, SVM, Random Forest, and Gradient Boosting pipelines. The system selects and deploys the highest scoring algorithm automatically.
            </p>
          </div>

          <div className="glass-panel p-8 rounded-3xl hover:translate-y-[-4px] transition-transform duration-300">
            <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 flex items-center justify-center text-emerald-500 mb-6">
              <Activity className="w-6 h-6" />
            </div>
            <h3 className="text-xl font-bold mb-3">Explainable Predictions</h3>
            <p className="text-slate-600 dark:text-slate-400 leading-relaxed text-sm">
              Every decision details exactly why it was made, scoring credit history, debt ratios, property metrics, and showing step-by-step guidance on how to fix errors.
            </p>
          </div>

          <div className="glass-panel p-8 rounded-3xl hover:translate-y-[-4px] transition-transform duration-300">
            <div className="w-12 h-12 rounded-2xl bg-indigo-500/10 flex items-center justify-center text-indigo-500 mb-6">
              <Shield className="w-6 h-6" />
            </div>
            <h3 className="text-xl font-bold mb-3">Bank-grade Security</h3>
            <p className="text-slate-600 dark:text-slate-400 leading-relaxed text-sm">
              All interactions are secured via SHA-256 JWT tokens. Sensitive data uses SQLite/Postgres schemas keeping application databases fully isolated.
            </p>
          </div>
        </div>
      </section>

      {/* How it Works */}
      <section className="bg-slate-100/50 dark:bg-slate-900/30 py-20">
        <div className="container mx-auto px-6">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <h2 className="text-3xl font-extrabold mb-4">How It Works</h2>
            <p className="text-slate-500 dark:text-slate-400 text-lg">Predict eligibility in three simple steps.</p>
          </div>

          <div className="grid md:grid-cols-3 gap-12 relative">
            <div className="text-center space-y-4">
              <div className="w-16 h-16 rounded-full bg-brand-500 text-white font-extrabold text-2xl flex items-center justify-center mx-auto shadow-lg shadow-brand-500/20">
                1
              </div>
              <h3 className="text-xl font-bold">Create Account</h3>
              <p className="text-slate-500 dark:text-slate-400 text-sm max-w-xs mx-auto">Register in seconds. Accounts support private user dashboards and secure data isolation.</p>
            </div>

            <div className="text-center space-y-4">
              <div className="w-16 h-16 rounded-full bg-brand-500 text-white font-extrabold text-2xl flex items-center justify-center mx-auto shadow-lg shadow-brand-500/20">
                2
              </div>
              <h3 className="text-xl font-bold">Input Details</h3>
              <p className="text-slate-500 dark:text-slate-400 text-sm max-w-xs mx-auto">Submit your applicant income, co-applicant stats, requested loan amount, and credit history score.</p>
            </div>

            <div className="text-center space-y-4">
              <div className="w-16 h-16 rounded-full bg-brand-500 text-white font-extrabold text-2xl flex items-center justify-center mx-auto shadow-lg shadow-brand-500/20">
                3
              </div>
              <h3 className="text-xl font-bold">Instant Prediction</h3>
              <p className="text-slate-500 dark:text-slate-400 text-sm max-w-xs mx-auto">Receive a prediction gauge (0-100%), full analytical breakdowns, and specific actions to secure approval.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Frequently Asked Questions */}
      <section className="container mx-auto px-6 py-20 max-w-4xl">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-extrabold mb-4">Frequently Asked Questions</h2>
          <p className="text-slate-500 dark:text-slate-400 text-lg">Clear answers to your technical questions.</p>
        </div>

        <div className="space-y-4">
          {faqs.map((faq, i) => (
            <div 
              key={i} 
              className="glass-panel rounded-2xl overflow-hidden transition-all duration-300"
            >
              <button
                onClick={() => toggleFaq(i)}
                className="w-full text-left px-8 py-5 flex items-center justify-between font-bold text-slate-800 dark:text-white"
              >
                <span>{faq.q}</span>
                <ChevronDown className={`w-5 h-5 text-slate-400 transition-transform duration-300 ${activeFaq === i ? "rotate-180" : ""}`} />
              </button>
              
              <div 
                className={`transition-all duration-300 ease-in-out ${activeFaq === i ? "max-h-60 border-t border-slate-100 dark:border-slate-800/80" : "max-h-0 pointer-events-none"}`}
                style={{ overflow: "hidden" }}
              >
                <p className="px-8 py-5 text-slate-600 dark:text-slate-300 text-sm leading-relaxed">
                  {faq.a}
                </p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* FAQ Banner CTA */}
      <section className="container mx-auto px-6 pb-20">
        <div className="bg-gradient-to-r from-brand-500 to-indigo-600 rounded-3xl p-10 sm:p-12 text-center text-white shadow-xl shadow-brand-500/10">
          <h2 className="text-3xl font-extrabold mb-4">Ready to Predict Your Status?</h2>
          <p className="text-indigo-100 max-w-xl mx-auto mb-8 font-medium">Create a free secure account to submit mock applications, track approvals, and build your eligibility scores.</p>
          <button
            onClick={() => onNavigate(isAuthenticated ? "dashboard" : "register")}
            className="px-8 py-4 bg-white text-brand-600 font-bold rounded-xl shadow-lg hover:shadow-xl hover:bg-slate-50 transition-all inline-flex items-center gap-2"
          >
            Launch Free Sandbox <ArrowRight className="w-5 h-5 text-brand-500" />
          </button>
        </div>
      </section>
    </div>
  );
}
