import React, { useState, useEffect } from "react";
import { api } from "../services/api";
import { User, Mail, Lock, ShieldCheck, CheckCircle2, AlertCircle } from "lucide-react";

export default function Profile({ user, onProfileUpdate }) {
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [success, setSuccess] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (user) {
      setFullName(user.full_name || "");
      setEmail(user.email || "");
    }
  }, [user]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setSuccess("");
    setLoading(true);

    try {
      const updateData = {
        full_name: fullName,
        email: email,
      };
      if (password) {
        if (password.length < 6) {
          throw new Error("Password must be at least 6 characters");
        }
        updateData.password = password;
      }

      const updatedUser = await api.updateProfile(updateData);
      onProfileUpdate(updatedUser);
      setSuccess("Profile updated successfully!");
      setPassword(""); // Clear password field
    } catch (err) {
      setError(err.message || "Failed to update profile");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto py-12 px-6">
      <div className="glass-panel p-8 rounded-3xl glow-primary">
        <h2 className="text-2xl font-bold mb-2 flex items-center gap-2">
          <User className="w-6 h-6 text-brand-500" /> Profile Settings
        </h2>
        <p className="text-sm text-slate-500 dark:text-slate-400 mb-8">
          Manage your personal information and security credentials
        </p>

        {success && (
          <div className="mb-6 p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-600 dark:text-emerald-400 text-sm flex items-center gap-3">
            <CheckCircle2 className="w-5 h-5 flex-shrink-0" />
            <span>{success}</span>
          </div>
        )}

        {error && (
          <div className="mb-6 p-4 rounded-xl bg-red-500/10 border border-red-500/20 text-red-600 dark:text-red-400 text-sm flex items-center gap-3">
            <AlertCircle className="w-5 h-5 flex-shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid sm:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-xs font-bold uppercase tracking-wider text-slate-400">Username</label>
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400">
                  <User className="w-4 h-4" />
                </span>
                <input
                  type="text"
                  value={user?.username || ""}
                  disabled
                  className="w-full glass-input pl-11 opacity-60 cursor-not-allowed bg-slate-100 dark:bg-slate-900"
                />
              </div>
              <p className="text-[10px] text-slate-400">Username cannot be modified.</p>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-bold uppercase tracking-wider text-slate-400">Account Access</label>
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400">
                  <ShieldCheck className="w-4 h-4" />
                </span>
                <input
                  type="text"
                  value={user?.is_admin ? "Administrator Account" : "Standard Client Sandbox"}
                  disabled
                  className="w-full glass-input pl-11 opacity-60 cursor-not-allowed bg-slate-100 dark:bg-slate-900"
                />
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-xs font-bold uppercase tracking-wider text-slate-400">Full Name</label>
            <div className="relative">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400">
                <User className="w-4 h-4" />
              </span>
              <input
                type="text"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                placeholder="Enter full name"
                className="w-full glass-input pl-11"
              />
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-xs font-bold uppercase tracking-wider text-slate-400">Email Address</label>
            <div className="relative">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400">
                <Mail className="w-4 h-4" />
              </span>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Enter email"
                className="w-full glass-input pl-11"
                required
              />
            </div>
          </div>

          <div className="space-y-2 pt-4 border-t border-slate-100 dark:border-slate-800/80">
            <label className="text-xs font-bold uppercase tracking-wider text-slate-400">Change Password</label>
            <div className="relative">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400">
                <Lock className="w-4 h-4" />
              </span>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter new password (leave blank to keep current)"
                className="w-full glass-input pl-11"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="px-8 py-3 rounded-xl bg-brand-500 hover:bg-brand-600 active:scale-[0.99] text-white font-bold transition-all shadow-md shadow-brand-500/10 disabled:opacity-50"
          >
            {loading ? "Saving Changes..." : "Save Changes"}
          </button>
        </form>
      </div>
    </div>
  );
}
