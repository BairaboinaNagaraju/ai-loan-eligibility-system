import React, { useState, useEffect } from "react";
import { api } from "../services/api";
import ApplicationForm from "../components/ApplicationForm";
import PredictionResult from "../components/PredictionResult";
import Calculators from "../components/Calculators";
import { 
  ResponsiveContainer, AreaChart, Area, XAxis, YAxis, CartesianGrid, 
  Tooltip, BarChart, Bar, PieChart, Pie, Cell, Legend 
} from "recharts";
import { 
  FileText, CheckCircle2, XCircle, Percent, PlusCircle, Search, 
  Trash2, TrendingUp, Sliders, ChevronDown, RotateCw, List
} from "lucide-react";

export default function Dashboard({ user, onNavigate, addNotification }) {
  const [stats, setStats] = useState(null);
  const [applications, setApplications] = useState([]);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  // Form & Prediction State
  const [showApplyModal, setShowApplyModal] = useState(false);
  const [applyLoading, setApplyLoading] = useState(false);
  const [predictionResult, setPredictionResult] = useState(null);
  const [lastSubmittedForm, setLastSubmittedForm] = useState(null);

  useEffect(() => {
    fetchDashboardData();
  }, [search, statusFilter]);

  const fetchDashboardData = async () => {
    try {
      setLoading(true);
      const [statsData, appsData] = await Promise.all([
        api.getDashboardStats(),
        api.getApplications(search, statusFilter)
      ]);
      setStats(statsData);
      setApplications(appsData);
    } catch (e) {
      addNotification("Data Fetch Error", e.message || "Failed to sync dashboard metrics.", "error");
    } finally {
      setLoading(false);
    }
  };

  const handleRefresh = async () => {
    setRefreshing(true);
    await fetchDashboardData();
    setRefreshing(false);
    addNotification("Synced", "Dashboard analytics updated successfully.", "success");
  };

  const handleApplySubmit = async (formData) => {
    setApplyLoading(true);
    setPredictionResult(null);
    setLastSubmittedForm(formData);
    try {
      const res = await api.submitApplication(formData);
      setPredictionResult(res);
      addNotification(
        "Application Analyzed", 
        `Loan predicted: ${res.prediction} (${Math.round(res.confidence_score * 100)}% confidence)`, 
        res.prediction === "Approved" ? "success" : "warning"
      );
      // Refresh statistics after successful submission
      fetchDashboardData();
    } catch (e) {
      addNotification("Submission Failed", e.message || "Error running credit model.", "error");
    } finally {
      setApplyLoading(false);
    }
  };

  const handleDeleteApplication = async (id) => {
    if (!confirm("Are you sure you want to delete this test application record?")) return;
    try {
      await api.deleteApplication(id);
      addNotification("Record Deleted", "Application entry removed.", "info");
      fetchDashboardData();
    } catch (e) {
      addNotification("Delete Failed", e.message || "Could not delete application.", "error");
    }
  };

  const COLORS = ["#3b82f6", "#10b981", "#f59e0b", "#ef4444"];

  return (
    <div className="container mx-auto px-6 py-10 space-y-10">
      
      {/* Welcome Banner */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-extrabold tracking-tight">
            Welcome back, <span className="text-brand-500">{user?.full_name || user?.username}</span>
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            EliteBank Credit Decision Sandbox dashboard panels.
          </p>
        </div>

        <div className="flex gap-3">
          <button 
            onClick={handleRefresh}
            disabled={refreshing}
            className="w-11 h-11 rounded-xl border border-slate-200 dark:border-slate-800 flex items-center justify-center hover:bg-slate-100 dark:hover:bg-slate-800 transition-all text-slate-600 dark:text-slate-300 disabled:opacity-50"
          >
            <RotateCw className={`w-4.5 h-4.5 ${refreshing ? "animate-spin" : ""}`} />
          </button>
          <button
            onClick={() => {
              setPredictionResult(null);
              setShowApplyModal(true);
            }}
            className="px-5 py-2.5 rounded-xl bg-brand-500 hover:bg-brand-600 text-white font-bold transition-all shadow-md shadow-brand-500/10 flex items-center gap-2 text-sm"
          >
            <PlusCircle className="w-4.5 h-4.5" /> Submit Application
          </button>
        </div>
      </div>

      {loading && !refreshing ? (
        <div className="grid md:grid-cols-4 gap-6 animate-pulse">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="h-32 bg-slate-200 dark:bg-slate-800 rounded-3xl"></div>
          ))}
        </div>
      ) : (
        <>
          {/* Metrics Overview Cards */}
          <div className="grid sm:grid-cols-2 md:grid-cols-4 gap-6">
            <div className="glass-panel p-6 rounded-3xl flex justify-between items-center relative overflow-hidden">
              <div className="space-y-2">
                <span className="text-xs text-slate-400 uppercase font-bold tracking-wider">Total Runs</span>
                <p className="text-3xl font-extrabold text-slate-900 dark:text-white">{stats?.total_applications || 0}</p>
              </div>
              <div className="w-12 h-12 rounded-2xl bg-brand-500/10 flex items-center justify-center text-brand-500">
                <FileText className="w-6 h-6" />
              </div>
            </div>

            <div className="glass-panel p-6 rounded-3xl flex justify-between items-center relative overflow-hidden">
              <div className="space-y-2">
                <span className="text-xs text-slate-400 uppercase font-bold tracking-wider">Approved Loans</span>
                <p className="text-3xl font-extrabold text-emerald-500">{stats?.approved_loans || 0}</p>
              </div>
              <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 flex items-center justify-center text-emerald-500">
                <CheckCircle2 className="w-6 h-6" />
              </div>
            </div>

            <div className="glass-panel p-6 rounded-3xl flex justify-between items-center relative overflow-hidden">
              <div className="space-y-2">
                <span className="text-xs text-slate-400 uppercase font-bold tracking-wider">Rejected Loans</span>
                <p className="text-3xl font-extrabold text-red-500">{stats?.rejected_loans || 0}</p>
              </div>
              <div className="w-12 h-12 rounded-2xl bg-red-500/10 flex items-center justify-center text-red-500">
                <XCircle className="w-6 h-6" />
              </div>
            </div>

            <div className="glass-panel p-6 rounded-3xl flex justify-between items-center relative overflow-hidden">
              <div className="space-y-2">
                <span className="text-xs text-slate-400 uppercase font-bold tracking-wider">Approval Rate</span>
                <p className="text-3xl font-extrabold text-slate-900 dark:text-white">
                  {stats?.approval_rate ? `${stats.approval_rate.toFixed(0)}%` : "0%"}
                </p>
              </div>
              <div className="w-12 h-12 rounded-2xl bg-brand-500/10 flex items-center justify-center text-brand-500">
                <Percent className="w-6 h-6" />
              </div>
            </div>
          </div>

          {/* Recharts Analytics Section */}
          <div className="grid md:grid-cols-2 gap-8">
            {/* Monthly Trend Area Chart */}
            <div className="glass-panel p-6 rounded-3xl">
              <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wider mb-6 flex items-center gap-1.5">
                <TrendingUp className="w-4 h-4 text-brand-500" /> Approval Trends
              </h3>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={stats?.loan_trends || []}>
                    <defs>
                      <linearGradient id="colorApproved" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#10b981" stopOpacity={0.3}/>
                        <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                      </linearGradient>
                      <linearGradient id="colorRejected" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#ef4444" stopOpacity={0.3}/>
                        <stop offset="95%" stopColor="#ef4444" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" className="dark:stroke-slate-800" />
                    <XAxis dataKey="month" stroke="#94a3b8" fontSize={11} tickLine={false} />
                    <YAxis stroke="#94a3b8" fontSize={11} tickLine={false} axisLine={false} />
                    <Tooltip />
                    <Legend />
                    <Area type="monotone" dataKey="Approved" stroke="#10b981" fillOpacity={1} fill="url(#colorApproved)" strokeWidth={2} />
                    <Area type="monotone" dataKey="Rejected" stroke="#ef4444" fillOpacity={1} fill="url(#colorRejected)" strokeWidth={2} />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Income Distribution Bar Chart */}
            <div className="glass-panel p-6 rounded-3xl">
              <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wider mb-6 flex items-center gap-1.5">
                <TrendingUp className="w-4 h-4 text-brand-500" /> Income Cohorts
              </h3>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={stats?.income_distribution || []}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" className="dark:stroke-slate-800" />
                    <XAxis dataKey="range" stroke="#94a3b8" fontSize={11} tickLine={false} />
                    <YAxis stroke="#94a3b8" fontSize={11} tickLine={false} axisLine={false} />
                    <Tooltip />
                    <Bar dataKey="Count" fill="#4f46e5" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Property Area Pie Chart */}
            <div className="glass-panel p-6 rounded-3xl flex flex-col justify-between">
              <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wider mb-4 flex items-center gap-1.5">
                <Sliders className="w-4 h-4 text-brand-500" /> Demographics by Property Area
              </h3>
              <div className="h-56 flex items-center justify-center">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={stats?.property_distribution || []}
                      cx="50%"
                      cy="50%"
                      innerRadius={45}
                      outerRadius={70}
                      paddingAngle={3}
                      dataKey="Count"
                      nameKey="area"
                    >
                      {(stats?.property_distribution || []).map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Credit History Comparison Bar Chart */}
            <div className="glass-panel p-6 rounded-3xl">
              <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wider mb-6 flex items-center gap-1.5">
                <Sliders className="w-4 h-4 text-brand-500" /> Credit History Success Ratio
              </h3>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={stats?.credit_history_comparison || []}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" className="dark:stroke-slate-800" />
                    <XAxis dataKey="history" stroke="#94a3b8" fontSize={11} tickLine={false} />
                    <YAxis stroke="#94a3b8" fontSize={11} tickLine={false} axisLine={false} />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="Approved" fill="#10b981" radius={[4, 4, 0, 0]} />
                    <Bar dataKey="Rejected" fill="#ef4444" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>

          {/* Interactive Calculators & Recommendation Engine */}
          <div className="glass-panel p-6 sm:p-8 rounded-3xl">
            <h2 className="text-xl font-bold mb-6 flex items-center gap-2">
              <Sliders className="w-5 h-5 text-brand-500" /> Financial Planning Tools
            </h2>
            <Calculators userProfile={applications[0]} />
          </div>

          {/* Previous/Recent Applications List Table */}
          <div className="glass-panel p-6 sm:p-8 rounded-3xl">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6 border-b border-slate-100 dark:border-slate-800/80 pb-4">
              <h3 className="text-lg font-bold flex items-center gap-2">
                <List className="w-5 h-5 text-brand-500" /> Recent Runs
              </h3>
              
              {/* Search & Status Filters */}
              <div className="flex flex-col sm:flex-row gap-3 w-full sm:w-auto">
                <div className="relative flex-1 sm:w-64">
                  <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400">
                    <Search className="w-4 h-4" />
                  </span>
                  <input
                    type="text"
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    placeholder="Search by area..."
                    className="w-full glass-input pl-10 py-2"
                  />
                </div>

                <select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                  className="glass-input py-2 pr-8"
                >
                  <option value="">All Statuses</option>
                  <option value="Approved">Approved</option>
                  <option value="Rejected">Rejected</option>
                </select>
              </div>
            </div>

            {applications.length === 0 ? (
              <p className="text-sm text-slate-400 text-center py-10 font-medium">
                No recent sandbox runs found. Click "Submit Application" to start.
              </p>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-sm">
                  <thead>
                    <tr className="border-b border-slate-100 dark:border-slate-800/80 text-slate-400 font-bold uppercase tracking-wider text-[11px]">
                      <th className="py-3 px-4">Date</th>
                      <th className="py-3 px-4">Income (Applicant/Co)</th>
                      <th className="py-3 px-4">Loan Principal</th>
                      <th className="py-3 px-4">Credit Score</th>
                      <th className="py-3 px-4">Area</th>
                      <th className="py-3 px-4">AI Prediction</th>
                      <th className="py-3 px-4 text-center">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {applications.map((app) => (
                      <tr 
                        key={app.id} 
                        className="border-b border-slate-100 dark:border-slate-800/40 hover:bg-slate-100/30 dark:hover:bg-slate-800/20 transition-all"
                      >
                        <td className="py-3.5 px-4 font-semibold text-slate-500">
                          {new Date(app.created_at).toLocaleDateString()}
                        </td>
                        <td className="py-3.5 px-4">
                          ${app.applicant_income} / ${app.coapplicant_income}
                        </td>
                        <td className="py-3.5 px-4 font-bold text-slate-800 dark:text-slate-200">
                          ${app.loan_amount}k
                        </td>
                        <td className="py-3.5 px-4">
                          <span className={`px-2 py-0.5 rounded-md font-bold text-[10px] ${app.credit_history === 1 ? "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400" : "bg-red-500/10 text-red-600 dark:text-red-400"}`}>
                            {app.credit_history === 1 ? "Clean (1.0)" : "Poor (0.0)"}
                          </span>
                        </td>
                        <td className="py-3.5 px-4 text-slate-500">{app.property_area}</td>
                        <td className="py-3.5 px-4">
                          <span className={`inline-flex items-center gap-1 font-bold text-xs ${app.prediction === "Approved" ? "text-emerald-500" : "text-red-500"}`}>
                            {app.prediction === "Approved" ? <CheckCircle2 className="w-3.5 h-3.5" /> : <XCircle className="w-3.5 h-3.5" />}
                            {app.prediction}
                          </span>
                        </td>
                        <td className="py-3.5 px-4 text-center">
                          <button
                            onClick={() => handleDeleteApplication(app.id)}
                            className="p-2 text-slate-400 hover:text-red-500 hover:bg-red-500/10 rounded-xl transition-all"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </>
      )}

      {/* Modal Application Form */}
      {showApplyModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 overflow-y-auto">
          <div className="relative w-full max-w-2xl my-8">
            <button
              onClick={() => setShowApplyModal(false)}
              className="absolute top-4 right-4 z-10 w-8 h-8 rounded-full border border-slate-200 dark:border-slate-800 flex items-center justify-center bg-white dark:bg-slate-900 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400"
            >
              <XCircle className="w-5 h-5" />
            </button>
            
            {!predictionResult ? (
              <ApplicationForm 
                onSubmit={handleApplySubmit} 
                loading={applyLoading} 
              />
            ) : (
              <PredictionResult 
                result={predictionResult} 
                formData={lastSubmittedForm}
                userName={user?.full_name || user?.username}
                onReset={() => setPredictionResult(null)}
              />
            )}
          </div>
        </div>
      )}

    </div>
  );
}
