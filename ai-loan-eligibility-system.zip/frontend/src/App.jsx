import React, { useState, useEffect } from "react";
import LandingPage from "./pages/LandingPage";
import Login from "./pages/Login";
import Register from "./pages/Register";
import Profile from "./pages/Profile";
import Dashboard from "./pages/Dashboard";
import AdminPanel from "./pages/AdminPanel";
import ChatAssistant from "./components/ChatAssistant";
import { 
  Sun, Moon, ShieldAlert, LogOut, User, LayoutDashboard, FileText, 
  Menu, X, Bell, Info
} from "lucide-react";

export default function App() {
  const [activePage, setActivePage] = useState("landing");
  const [user, setUser] = useState(null);
  const [darkMode, setDarkMode] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [notifications, setNotifications] = useState([]);
  const [showNotificationsList, setShowNotificationsList] = useState(false);

  // Sync token-based session on launch
  useEffect(() => {
    const token = localStorage.getItem("token");
    const storedUser = localStorage.getItem("user");
    if (token && storedUser) {
      try {
        setUser(JSON.parse(storedUser));
        setActivePage("dashboard");
        addNotification("Session restored", "Successfully logged in automatically.", "info");
      } catch (e) {
        localStorage.clear();
      }
    }

    // Set default dark mode based on preference
    const isDark = localStorage.getItem("darkMode") === "true";
    setDarkMode(isDark);
    if (isDark) {
      document.body.classList.add("dark");
    } else {
      document.body.classList.remove("dark");
    }
  }, []);

  const toggleDarkMode = () => {
    const newDark = !darkMode;
    setDarkMode(newDark);
    localStorage.setItem("darkMode", String(newDark));
    if (newDark) {
      document.body.classList.add("dark");
    } else {
      document.body.classList.remove("dark");
    }
    addNotification("Theme Toggled", `Switched to ${newDark ? "Dark" : "Light"} mode.`, "info");
  };

  const handleLoginSuccess = (userData) => {
    setUser(userData);
    setActivePage("dashboard");
    addNotification("Login successful", `Welcome back, ${userData.full_name || userData.username}!`, "success");
  };

  const handleProfileUpdate = (updatedUser) => {
    setUser(updatedUser);
    addNotification("Profile Updated", "Your changes have been saved successfully.", "success");
  };

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    setUser(null);
    setActivePage("landing");
    addNotification("Logged Out", "You have been logged out of the session.", "info");
  };

  const addNotification = (title, message, type = "info") => {
    const id = Date.now();
    setNotifications((prev) => [
      { id, title, message, type, time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) },
      ...prev
    ]);
  };

  const removeNotification = (id) => {
    setNotifications((prev) => prev.filter((n) => n.id !== id));
  };

  return (
    <div className="flex flex-col min-h-screen text-slate-900 dark:text-slate-100 transition-colors duration-200">
      {/* Header / Navbar */}
      <header className="sticky top-0 z-50 glass-panel border-b border-slate-200/50 dark:border-slate-800/50">
        <nav className="container mx-auto px-6 h-20 flex items-center justify-between">
          <div 
            onClick={() => setActivePage("landing")} 
            className="flex items-center gap-2 cursor-pointer"
          >
            <span className="text-2xl">🏦</span>
            <span className="font-extrabold text-xl tracking-tight bg-gradient-to-r from-brand-500 to-indigo-500 bg-clip-text text-transparent">
              EliteBank AI
            </span>
          </div>

          {/* Desktop Nav Items */}
          <div className="hidden md:flex items-center gap-6">
            <button 
              onClick={() => setActivePage("landing")}
              className={`text-sm font-semibold hover:text-brand-500 transition-colors ${activePage === "landing" ? "text-brand-500" : ""}`}
            >
              Home
            </button>

            {user && (
              <>
                <button 
                  onClick={() => setActivePage("dashboard")}
                  className={`text-sm font-semibold hover:text-brand-500 transition-colors flex items-center gap-1.5 ${activePage === "dashboard" ? "text-brand-500" : ""}`}
                >
                  <LayoutDashboard className="w-4 h-4" /> Dashboard
                </button>

                {user.is_admin && (
                  <button 
                    onClick={() => setActivePage("admin")}
                    className={`text-sm font-semibold hover:text-brand-500 transition-colors flex items-center gap-1.5 ${activePage === "admin" ? "text-brand-500" : ""}`}
                  >
                    <ShieldAlert className="w-4 h-4 text-amber-500" /> Admin Panel
                  </button>
                )}

                <button 
                  onClick={() => setActivePage("profile")}
                  className={`text-sm font-semibold hover:text-brand-500 transition-colors flex items-center gap-1.5 ${activePage === "profile" ? "text-brand-500" : ""}`}
                >
                  <User className="w-4 h-4" /> Profile
                </button>
              </>
            )}
          </div>

          {/* User Section / Action Buttons */}
          <div className="hidden md:flex items-center gap-4">
            {/* Notification Bell */}
            <div className="relative">
              <button 
                onClick={() => setShowNotificationsList(!showNotificationsList)}
                className="w-10 h-10 rounded-full border border-slate-200 dark:border-slate-800 flex items-center justify-center hover:bg-slate-100 dark:hover:bg-slate-800 transition-all"
              >
                <Bell className="w-4.5 h-4.5" />
                {notifications.length > 0 && (
                  <span className="absolute top-1 right-1 w-2.5 h-2.5 bg-red-500 rounded-full"></span>
                )}
              </button>

              {showNotificationsList && (
                <div className="absolute right-0 mt-3 w-80 glass-panel p-4 rounded-2xl shadow-xl z-50 max-h-96 overflow-y-auto">
                  <div className="flex justify-between items-center mb-3 pb-2 border-b border-slate-100 dark:border-slate-800">
                    <span className="font-bold text-sm">Notifications</span>
                    <button 
                      onClick={() => setNotifications([])}
                      className="text-xs text-brand-500 dark:text-brand-400 hover:underline"
                    >
                      Clear All
                    </button>
                  </div>
                  {notifications.length === 0 ? (
                    <p className="text-xs text-slate-400 text-center py-4">No new notifications</p>
                  ) : (
                    <div className="space-y-3">
                      {notifications.map((n) => (
                        <div key={n.id} className="text-xs space-y-1 relative pr-4">
                          <p className="font-bold text-slate-800 dark:text-slate-200">{n.title}</p>
                          <p className="text-slate-500 dark:text-slate-400 leading-normal">{n.message}</p>
                          <span className="text-[9px] text-slate-400">{n.time}</span>
                          <button 
                            onClick={() => removeNotification(n.id)}
                            className="absolute top-0 right-0 text-slate-400 hover:text-slate-600"
                          >
                            <X className="w-3 h-3" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Dark Mode Toggle */}
            <button
              onClick={toggleDarkMode}
              className="w-10 h-10 rounded-full border border-slate-200 dark:border-slate-800 flex items-center justify-center hover:bg-slate-100 dark:hover:bg-slate-800 transition-all text-slate-600 dark:text-slate-300"
            >
              {darkMode ? <Sun className="w-5 h-5 text-amber-400" /> : <Moon className="w-5 h-5" />}
            </button>

            {user ? (
              <button
                onClick={handleLogout}
                className="px-4 py-2 text-sm font-semibold rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 transition-all flex items-center gap-1.5"
              >
                <LogOut className="w-4 h-4" /> Sign Out
              </button>
            ) : (
              <div className="flex gap-2">
                <button
                  onClick={() => setActivePage("login")}
                  className="px-4 py-2 text-sm font-bold text-brand-500 dark:text-brand-400 hover:underline"
                >
                  Sign In
                </button>
                <button
                  onClick={() => setActivePage("register")}
                  className="px-5 py-2 text-sm font-bold bg-brand-500 hover:bg-brand-600 text-white rounded-xl shadow-md shadow-brand-500/10 transition-all"
                >
                  Register
                </button>
              </div>
            )}
          </div>

          {/* Mobile Menu Icon */}
          <div className="md:hidden flex items-center gap-3">
            <button
              onClick={toggleDarkMode}
              className="w-9 h-9 rounded-full border border-slate-200 dark:border-slate-800 flex items-center justify-center text-slate-600 dark:text-slate-300"
            >
              {darkMode ? <Sun className="w-4.5 h-4.5 text-amber-400" /> : <Moon className="w-4.5 h-4.5" />}
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="w-9 h-9 rounded-full border border-slate-200 dark:border-slate-800 flex items-center justify-center text-slate-600 dark:text-slate-300"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </nav>

        {/* Mobile Dropdown Nav */}
        {mobileMenuOpen && (
          <div className="md:hidden border-t border-slate-100 dark:border-slate-800 px-6 py-4 bg-white dark:bg-slate-950 space-y-4">
            <button
              onClick={() => { setActivePage("landing"); setMobileMenuOpen(false); }}
              className="block w-full text-left font-semibold py-2"
            >
              Home
            </button>
            {user ? (
              <>
                <button
                  onClick={() => { setActivePage("dashboard"); setMobileMenuOpen(false); }}
                  className="block w-full text-left font-semibold py-2"
                >
                  Dashboard
                </button>
                {user.is_admin && (
                  <button
                    onClick={() => { setActivePage("admin"); setMobileMenuOpen(false); }}
                    className="block w-full text-left font-semibold py-2 text-amber-500"
                  >
                    Admin Panel
                  </button>
                )}
                <button
                  onClick={() => { setActivePage("profile"); setMobileMenuOpen(false); }}
                  className="block w-full text-left font-semibold py-2"
                >
                  Profile Settings
                </button>
                <button
                  onClick={() => { handleLogout(); setMobileMenuOpen(false); }}
                  className="block w-full text-left font-semibold py-2 text-red-500 flex items-center gap-1.5"
                >
                  <LogOut className="w-4 h-4" /> Sign Out
                </button>
              </>
            ) : (
              <div className="pt-2 flex flex-col gap-2">
                <button
                  onClick={() => { setActivePage("login"); setMobileMenuOpen(false); }}
                  className="w-full py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 font-bold"
                >
                  Sign In
                </button>
                <button
                  onClick={() => { setActivePage("register"); setMobileMenuOpen(false); }}
                  className="w-full py-2.5 rounded-xl bg-brand-500 text-white font-bold"
                >
                  Register Free
                </button>
              </div>
            )}
          </div>
        )}
      </header>

      {/* Main Content Area */}
      <main className="flex-1 w-full bg-slate-50 dark:bg-navy-950 transition-colors duration-200">
        {activePage === "landing" && (
          <LandingPage 
            onNavigate={setActivePage} 
            isAuthenticated={!!user} 
          />
        )}
        {activePage === "login" && (
          <Login 
            onLoginSuccess={handleLoginSuccess} 
            onNavigate={setActivePage} 
          />
        )}
        {activePage === "register" && (
          <Register 
            onLoginSuccess={handleLoginSuccess} 
            onNavigate={setActivePage} 
          />
        )}
        {activePage === "profile" && (
          <Profile 
            user={user} 
            onProfileUpdate={handleProfileUpdate} 
          />
        )}
        {activePage === "dashboard" && (
          <Dashboard 
            user={user} 
            onNavigate={setActivePage} 
            addNotification={addNotification} 
          />
        )}
        {activePage === "admin" && (
          <AdminPanel 
            user={user} 
            addNotification={addNotification} 
          />
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-200/50 dark:border-slate-800/50 py-8 bg-white dark:bg-slate-950 text-center text-xs text-slate-500 dark:text-slate-400">
        <div className="container mx-auto px-6 space-y-4">
          <div className="flex justify-center gap-6 font-semibold">
            <span className="hover:text-brand-500 cursor-pointer">Security Policy</span>
            <span className="hover:text-brand-500 cursor-pointer">Terms of Service</span>
            <span className="hover:text-brand-500 cursor-pointer">API Integration</span>
            <span className="hover:text-brand-500 cursor-pointer">Developer Docs</span>
          </div>
          <p>© 2026 EliteBank AI Systems Inc. All rights reserved. Powered by Explainable Machine Learning.</p>
        </div>
      </footer>

      {/* AI Chat Assistant */}
      <ChatAssistant user={user} addNotification={addNotification} />
    </div>
  );
}
