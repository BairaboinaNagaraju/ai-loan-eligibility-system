const API_BASE_URL = "http://localhost:8000/api";

const getHeaders = () => {
  const token = localStorage.getItem("token");
  const headers = {
    "Content-Type": "application/json",
  };
  if (token) {
    headers["Authorization"] = `Bearer ${token}`;
  }
  return headers;
};

const handleResponse = async (response) => {
  if (!response.ok) {
    let errorMessage = "An error occurred";
    try {
      const errorData = await response.json();
      errorMessage = errorData.detail || errorData.message || errorMessage;
    } catch (e) {
      // JSON parsing failed, use statusText
      errorMessage = response.statusText || errorMessage;
    }
    throw new Error(errorMessage);
  }
  return response.json();
};

export const api = {
  // --- Authentication ---
  login: async (username, password) => {
    const res = await fetch(`${API_BASE_URL}/auth/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, password }),
    });
    const data = await handleResponse(res);
    localStorage.setItem("token", data.access_token);
    localStorage.setItem("user", JSON.stringify(data.user));
    return data;
  },

  register: async (username, email, password, full_name) => {
    const res = await fetch(`${API_BASE_URL}/auth/register`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, email, password, full_name }),
    });
    return handleResponse(res);
  },

  logout: () => {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
  },

  getMe: async () => {
    const res = await fetch(`${API_BASE_URL}/auth/me`, {
      method: "GET",
      headers: getHeaders(),
    });
    return handleResponse(res);
  },

  updateProfile: async (profileData) => {
    const res = await fetch(`${API_BASE_URL}/auth/profile`, {
      method: "PUT",
      headers: getHeaders(),
      body: JSON.stringify(profileData),
    });
    const updatedUser = await handleResponse(res);
    localStorage.setItem("user", JSON.stringify(updatedUser));
    return updatedUser;
  },

  // --- Loan Prediction (Anonymous / Sandbox) ---
  predictSandbox: async (formData) => {
    const res = await fetch(`${API_BASE_URL}/predict`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(formData),
    });
    return handleResponse(res);
  },

  // --- Loan Applications (Authenticated) ---
  submitApplication: async (formData) => {
    const res = await fetch(`${API_BASE_URL}/applications`, {
      method: "POST",
      headers: getHeaders(),
      body: JSON.stringify(formData),
    });
    return handleResponse(res);
  },

  getApplications: async (search = "", statusFilter = "") => {
    let url = `${API_BASE_URL}/applications`;
    const params = [];
    if (search) params.push(`search=${encodeURIComponent(search)}`);
    if (statusFilter) params.push(`status_filter=${encodeURIComponent(statusFilter)}`);
    if (params.length > 0) {
      url += `?${params.join("&")}`;
    }

    const res = await fetch(url, {
      method: "GET",
      headers: getHeaders(),
    });
    return handleResponse(res);
  },

  deleteApplication: async (id) => {
    const res = await fetch(`${API_BASE_URL}/applications/${id}`, {
      method: "DELETE",
      headers: getHeaders(),
    });
    return handleResponse(res);
  },

  // --- Dashboards ---
  getDashboardStats: async () => {
    const res = await fetch(`${API_BASE_URL}/dashboard`, {
      method: "GET",
      headers: getHeaders(),
    });
    return handleResponse(res);
  },

  getAdminDashboardStats: async () => {
    const res = await fetch(`${API_BASE_URL}/dashboard/admin`, {
      method: "GET",
      headers: getHeaders(),
    });
    return handleResponse(res);
  },

  getAdminUsers: async () => {
    const res = await fetch(`${API_BASE_URL}/dashboard/admin/users`, {
      method: "GET",
      headers: getHeaders(),
    });
    return handleResponse(res);
  },
  
  // --- Simulated endpoints ---
  sendEmailReport: async (email, applicationDetails) => {
    // Simulate sending email api call
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve({ success: true, message: `Report successfully emailed to ${email}!` });
      }, 1000);
    });
  }
};
