import React, { useState } from "react";
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from "recharts";
import { 
  Calculator, Scale, Sparkles, DollarSign, Clock, Percent, 
  HelpCircle, ThumbsUp, ArrowRight, ShieldCheck, Award
} from "lucide-react";

export default function Calculators({ userProfile }) {
  const [activeTab, setActiveTab] = useState("emi");

  // --- EMI Calculator State ---
  const [emiAmount, setEmiAmount] = useState(150000);
  const [emiTerm, setEmiTerm] = useState(180); // in months
  const [emiRate, setEmiRate] = useState(8.5);

  const calculateEmi = () => {
    const monthlyRate = emiRate / 12 / 100;
    const emi = (emiAmount * monthlyRate * Math.pow(1 + monthlyRate, emiTerm)) / 
                (Math.pow(1 + monthlyRate, emiTerm) - 1);
    const totalRepay = emi * emiTerm;
    const totalInterest = totalRepay - emiAmount;
    return {
      emi: isNaN(emi) || !isFinite(emi) ? 0 : emi,
      totalInterest: isNaN(totalInterest) || totalInterest < 0 ? 0 : totalInterest,
      totalRepay: isNaN(totalRepay) || totalRepay < 0 ? 0 : totalRepay
    };
  };

  const { emi, totalInterest, totalRepay } = calculateEmi();

  const emiChartData = [
    { name: "Principal Amount", value: emiAmount, color: "#4f46e5" },
    { name: "Total Interest", value: totalInterest, color: "#10b981" }
  ];

  // --- Affordability State ---
  const [monthlyIncome, setMonthlyIncome] = useState(6000);
  const [monthlyDebts, setMonthlyDebts] = useState(1500);
  const [affordRate, setAffordRate] = useState(8.5);
  const [affordTerm, setAffordTerm] = useState(20); // in years

  const calculateAffordability = () => {
    // Max monthly payment allowed is 40% of Net Monthly Income
    const netIncome = monthlyIncome - monthlyDebts;
    const maxEmi = Math.max(netIncome * 0.40, 0);
    
    // Calculate maximum loan amount based on maxEmi
    const termMonths = affordTerm * 12;
    const r = affordRate / 12 / 100;
    
    const maxLoan = r > 0 
      ? (maxEmi * (Math.pow(1 + r, termMonths) - 1)) / (r * Math.pow(1 + r, termMonths))
      : maxEmi * termMonths;

    let tier = "Stretched";
    let color = "text-red-500 border-red-500/20 bg-red-500/5";
    if (netIncome <= 0) {
      tier = "Deficit";
      color = "text-red-600 bg-red-600/10";
    } else {
      const dti = (monthlyDebts / monthlyIncome) * 100;
      if (dti <= 30) {
        tier = "Excellent";
        color = "text-emerald-500 border-emerald-500/20 bg-emerald-500/5";
      } else if (dti <= 45) {
        tier = "Moderate";
        color = "text-amber-500 border-amber-500/20 bg-amber-500/5";
      }
    }

    return {
      maxEmi,
      maxLoan: isNaN(maxLoan) || !isFinite(maxLoan) ? 0 : maxLoan,
      tier,
      color
    };
  };

  const { maxEmi, maxLoan, tier, color } = calculateAffordability();

  // --- Recommendations State ---
  const creditScore = userProfile?.credit_history === 0 ? "Poor" : "Excellent";
  
  const recommendationsList = [
    {
      title: "Elite Home Purchase Loan",
      interest: "7.2% - 8.5%",
      term: "15 - 30 Years",
      suitability: creditScore === "Excellent" ? "High Approval" : "Medium Approval (Requires Credit Fix)",
      desc: "Premium housing credit lines. Clean credit history guarantees our lowest rate.",
      icon: "🏠"
    },
    {
      title: "Business Capital Expansion",
      interest: "8.9% - 10.5%",
      term: "3 - 7 Years",
      suitability: "Requires Salaried/Self-Employed Co-applicant",
      desc: "Startup or capital runway expansion credit line. Approval probability rises with added co-applicant incomes.",
      icon: "📈"
    },
    {
      title: "Flexible Unsecured Personal Line",
      interest: "11.2% - 14.5%",
      term: "1 - 5 Years",
      suitability: "Medium Approval (Based on Income DTI)",
      desc: "Fast liquidity overdraft for personal expenses. Higher APR, but requires no asset collateral verification.",
      icon: "💳"
    }
  ];

  return (
    <div className="w-full space-y-6">
      {/* Tabs headers */}
      <div className="flex border-b border-slate-200 dark:border-slate-800">
        <button
          onClick={() => setActiveTab("emi")}
          className={`flex items-center gap-1.5 px-6 py-4 font-bold text-sm border-b-2 transition-all ${
            activeTab === "emi"
              ? "border-brand-500 text-brand-500 dark:text-brand-400"
              : "border-transparent text-slate-500 hover:text-slate-700 dark:hover:text-slate-300"
          }`}
        >
          <Calculator className="w-4 h-4" /> EMI Calculator
        </button>

        <button
          onClick={() => setActiveTab("afford")}
          className={`flex items-center gap-1.5 px-6 py-4 font-bold text-sm border-b-2 transition-all ${
            activeTab === "afford"
              ? "border-brand-500 text-brand-500 dark:text-brand-400"
              : "border-transparent text-slate-500 hover:text-slate-700 dark:hover:text-slate-300"
          }`}
        >
          <Scale className="w-4 h-4" /> Affordability Gauge
        </button>

        <button
          onClick={() => setActiveTab("engine")}
          className={`flex items-center gap-1.5 px-6 py-4 font-bold text-sm border-b-2 transition-all ${
            activeTab === "engine"
              ? "border-brand-500 text-brand-500 dark:text-brand-400"
              : "border-transparent text-slate-500 hover:text-slate-700 dark:hover:text-slate-300"
          }`}
        >
          <Sparkles className="w-4 h-4" /> Recommendation Engine
        </button>
      </div>

      {/* Tabs Content */}
      <div className="p-2">
        
        {/* TAB 1: EMI Calculator */}
        {activeTab === "emi" && (
          <div className="flex flex-col lg:flex-row gap-10 animate-[fadeIn_0.3s_ease-out]">
            {/* Sliders Area */}
            <div className="flex-1 space-y-6">
              <div>
                <div className="flex justify-between text-sm font-semibold mb-2">
                  <span className="flex items-center gap-1"><DollarSign className="w-4 h-4 text-slate-400" /> Loan Principal</span>
                  <span className="text-brand-500 font-bold">${emiAmount.toLocaleString()}</span>
                </div>
                <input 
                  type="range" 
                  min="5000" 
                  max="1000000" 
                  step="5000"
                  value={emiAmount} 
                  onChange={(e) => setEmiAmount(Number(e.target.value))}
                  className="w-full accent-brand-500 h-1.5 bg-slate-200 dark:bg-slate-800 rounded-lg cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between text-sm font-semibold mb-2">
                  <span className="flex items-center gap-1"><Clock className="w-4 h-4 text-slate-400" /> Repayment Tenure</span>
                  <span className="text-brand-500 font-bold">{emiTerm} Months ({Math.round(emiTerm/12)} Yrs)</span>
                </div>
                <input 
                  type="range" 
                  min="12" 
                  max="360" 
                  step="12"
                  value={emiTerm} 
                  onChange={(e) => setEmiTerm(Number(e.target.value))}
                  className="w-full accent-brand-500 h-1.5 bg-slate-200 dark:bg-slate-800 rounded-lg cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between text-sm font-semibold mb-2">
                  <span className="flex items-center gap-1"><Percent className="w-4 h-4 text-slate-400" /> Interest Rate</span>
                  <span className="text-brand-500 font-bold">{emiRate}% APR</span>
                </div>
                <input 
                  type="range" 
                  min="3.5" 
                  max="18" 
                  step="0.1"
                  value={emiRate} 
                  onChange={(e) => setEmiRate(Number(e.target.value))}
                  className="w-full accent-brand-500 h-1.5 bg-slate-200 dark:bg-slate-800 rounded-lg cursor-pointer"
                />
              </div>

              <div className="grid grid-cols-3 gap-4 pt-6 border-t border-slate-100 dark:border-slate-800/80 text-center">
                <div className="bg-slate-100/50 dark:bg-slate-900/40 p-4 rounded-2xl">
                  <span className="text-[10px] text-slate-500 dark:text-slate-400 uppercase font-bold">Monthly EMI</span>
                  <p className="text-xl sm:text-2xl font-extrabold mt-1 text-brand-500">${Math.round(emi).toLocaleString()}</p>
                </div>
                <div className="bg-slate-100/50 dark:bg-slate-900/40 p-4 rounded-2xl">
                  <span className="text-[10px] text-slate-500 dark:text-slate-400 uppercase font-bold">Total Interest</span>
                  <p className="text-xl sm:text-2xl font-extrabold mt-1 text-emerald-500">${Math.round(totalInterest).toLocaleString()}</p>
                </div>
                <div className="bg-slate-100/50 dark:bg-slate-900/40 p-4 rounded-2xl">
                  <span className="text-[10px] text-slate-500 dark:text-slate-400 uppercase font-bold">Total Repay</span>
                  <p className="text-xl sm:text-2xl font-extrabold mt-1 text-slate-900 dark:text-white">${Math.round(totalRepay).toLocaleString()}</p>
                </div>
              </div>
            </div>

            {/* Visual Chart Area */}
            <div className="w-full lg:w-72 flex flex-col items-center justify-center border-t lg:border-t-0 lg:border-l border-slate-100 dark:border-slate-800/80 pt-8 lg:pt-0 lg:pl-10">
              <span className="text-xs text-slate-400 uppercase font-bold tracking-wider mb-4">Payment Breakdown</span>
              <div className="w-48 h-48 relative">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={emiChartData}
                      cx="50%"
                      cy="50%"
                      innerRadius={50}
                      outerRadius={75}
                      paddingAngle={4}
                      dataKey="value"
                    >
                      {emiChartData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value) => `$${Math.round(value).toLocaleString()}`} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="flex gap-4 mt-4 text-xs font-semibold">
                <div className="flex items-center gap-1.5">
                  <span className="w-3 h-3 rounded-full bg-[#4f46e5]"></span> Principal
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="w-3 h-3 rounded-full bg-[#10b981]"></span> Interest
                </div>
              </div>
            </div>

          </div>
        )}

        {/* TAB 2: Affordability Calculator */}
        {activeTab === "afford" && (
          <div className="space-y-6 max-w-2xl mx-auto animate-[fadeIn_0.3s_ease-out]">
            <div className="grid sm:grid-cols-2 gap-6">
              <div>
                <div className="flex justify-between text-sm font-semibold mb-2">
                  <span>Monthly Gross Income</span>
                  <span className="text-brand-500 font-bold">${monthlyIncome.toLocaleString()}</span>
                </div>
                <input 
                  type="range" 
                  min="1000" 
                  max="30000" 
                  step="500"
                  value={monthlyIncome} 
                  onChange={(e) => setMonthlyIncome(Number(e.target.value))}
                  className="w-full accent-brand-500 h-1.5 bg-slate-200 dark:bg-slate-800 rounded-lg cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between text-sm font-semibold mb-2">
                  <span>Existing Monthly Debts</span>
                  <span className="text-brand-500 font-bold">${monthlyDebts.toLocaleString()}</span>
                </div>
                <input 
                  type="range" 
                  min="0" 
                  max="15000" 
                  step="250"
                  value={monthlyDebts} 
                  onChange={(e) => setMonthlyDebts(Number(e.target.value))}
                  className="w-full accent-brand-500 h-1.5 bg-slate-200 dark:bg-slate-800 rounded-lg cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between text-sm font-semibold mb-2">
                  <span>Assumed Interest Rate</span>
                  <span className="text-brand-500 font-bold">{affordRate}% APR</span>
                </div>
                <input 
                  type="range" 
                  min="4" 
                  max="16" 
                  step="0.1"
                  value={affordRate} 
                  onChange={(e) => setAffordRate(Number(e.target.value))}
                  className="w-full accent-brand-500 h-1.5 bg-slate-200 dark:bg-slate-800 rounded-lg cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between text-sm font-semibold mb-2">
                  <span>Assumed Loan Tenure</span>
                  <span className="text-brand-500 font-bold">{affordTerm} Years</span>
                </div>
                <input 
                  type="range" 
                  min="5" 
                  max="30" 
                  step="5"
                  value={affordTerm} 
                  onChange={(e) => setAffordTerm(Number(e.target.value))}
                  className="w-full accent-brand-500 h-1.5 bg-slate-200 dark:bg-slate-800 rounded-lg cursor-pointer"
                />
              </div>
            </div>

            {/* Results Alert Area */}
            <div className="pt-6 border-t border-slate-100 dark:border-slate-800/80 flex flex-col sm:flex-row items-center justify-between gap-6">
              <div className="space-y-1">
                <span className="text-xs text-slate-400 uppercase font-bold tracking-wider">Estimated Max Borrowing</span>
                <h3 className="text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-white">
                  ${Math.round(maxLoan).toLocaleString()}
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                  Assumes a maximum affordable monthly payment of <span className="font-bold text-brand-500">${Math.round(maxEmi)}</span>
                </p>
              </div>

              <div className={`px-4 py-3 rounded-2xl border text-sm font-bold flex items-center gap-2 ${color}`}>
                <ShieldCheck className="w-4.5 h-4.5" /> Debt Tier: {tier}
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: AI Loan Recommendation Engine */}
        {activeTab === "engine" && (
          <div className="space-y-5 animate-[fadeIn_0.3s_ease-out]">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-brand-500/10 dark:bg-brand-400/10 border border-brand-500/20 text-brand-600 dark:text-brand-400 text-xs font-bold mb-4">
              <Sparkles className="w-3.5 h-3.5" /> Smart Recommendations Engine
            </div>

            <div className="grid md:grid-cols-3 gap-6">
              {recommendationsList.map((rec, index) => (
                <div 
                  key={index}
                  className="glass-panel p-6 rounded-2xl flex flex-col justify-between hover:translate-y-[-2px] transition-transform"
                >
                  <div className="space-y-4">
                    <div className="text-3xl">{rec.icon}</div>
                    <div>
                      <h4 className="font-bold text-slate-900 dark:text-white text-base">{rec.title}</h4>
                      <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed mt-2">{rec.desc}</p>
                    </div>
                  </div>

                  <div className="space-y-3 pt-4 border-t border-slate-100 dark:border-slate-800/80 mt-4 text-xs font-semibold">
                    <div className="flex justify-between">
                      <span className="text-slate-400">Interest Rates</span>
                      <span>{rec.interest}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Tenure Terms</span>
                      <span>{rec.term}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400 font-bold text-brand-500">Likelihood</span>
                      <span className="text-brand-500 font-bold">{rec.suitability}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
