import React, { useState, useRef, useEffect } from "react";
import { MessageSquare, X, Send, User, Bot, Sparkles, HelpCircle } from "lucide-react";

export default function ChatAssistant({ user, addNotification }) {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState([
    {
      id: 1,
      sender: "bot",
      text: "Hello! I am your EliteBank Credit Assistant. How can I help you with your loan eligibility sandbox today?",
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);
  const [input, setInput] = useState("");
  const messagesEndRef = useRef(null);

  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages]);

  const handleSend = (e) => {
    e.preventDefault();
    if (!input.trim()) return;

    const userText = input.trim();
    const newMsg = {
      id: Date.now(),
      sender: "user",
      text: userText,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages((prev) => [...prev, newMsg]);
    setInput("");

    // Simulate thinking and generate bot response
    setTimeout(() => {
      const responseText = generateBotResponse(userText);
      const botMsg = {
        id: Date.now() + 1,
        sender: "bot",
        text: responseText,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setMessages((prev) => [...prev, botMsg]);
      addNotification("New chatbot message", "Credit Assistant answered your query.", "info");
    }, 1000);
  };

  const generateBotResponse = (query) => {
    const q = query.toLowerCase();
    
    // Keyword Matching Rules
    if (q.includes("hi") || q.includes("hello") || q.includes("hey")) {
      return `Hi there! I am ready to guide you. You can ask me about:
1. "How to improve my credit score?"
2. "How does the AI model predict loan status?"
3. "Explain the EMI calculation formula."
4. "What features does the admin panel offer?"`;
    }
    
    if (q.includes("credit") || q.includes("history") || q.includes("score")) {
      return "Credit History is the single most critical feature in our model. A score of 1.0 (clean history) is almost always required for approvals. If your history is poor (0.0), you can improve eligibility by: 1) Paying off outstanding credit card balances, 2) Resolving active defaults, 3) Applying with a co-applicant who has an excellent credit score.";
    }

    if (q.includes("emi") || q.includes("interest") || q.includes("calculate") || q.includes("repay")) {
      return "EMI (Equated Monthly Installment) is calculated using: P * r * (1 + r)^n / ((1 + r)^n - 1), where P is Loan Principal, r is Monthly Interest Rate, and n is Tenure in Months. You can use our built-in EMI Calculator on the Dashboard to simulate payments with a visual breakdown!";
    }

    if (q.includes("predict") || q.includes("model") || q.includes("accuracy") || q.includes("ai")) {
      return "We train 6 ML models: Logistic Regression, Decision Trees, Random Forests, Gradient Boosting, SVM, and XGBoost. The system automatically deploys the best performing classifier. Our current champion model achieves 82.5% accuracy. In addition, we use Local Explainable AI to list positive/negative indicators for every prediction.";
    }

    if (q.includes("admin") || q.includes("export") || q.includes("retrain")) {
      return "The Admin Panel allows authorized personnel to view all users, manage all loan applications, search applicants, export tables to CSV, and execute model retraining on the raw dataset in real-time. If you register with the username 'admin', you will automatically receive Admin access!";
    }

    if (q.includes("income") || q.includes("coapplicant") || q.includes("salary")) {
      return "Applicant and Co-Applicant incomes represent your total monthly cashflow. The model uses your Debt-to-Income (DTI) ratio (Loan amount relative to annual combined income). If your income is low, adding a co-applicant with a solid salary significantly boosts your approval confidence score!";
    }

    if (q.includes("status") || q.includes("my loan") || q.includes("application")) {
      if (user) {
        return `Hello, ${user.full_name || user.username}. You can check all your previous application predictions and confidence metrics directly in the "Recent Applications" card on your Dashboard. You can also edit your profile or delete old test records.`;
      } else {
        return "To submit applications and track your eligibility history, please Sign In or Register a free account first!";
      }
    }

    return "I'm not sure I fully understand. You can ask me about 'credit history score', 'calculating EMI', 'how the AI models are trained', or 'admin dashboard functionalities'.";
  };

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end">
      
      {/* Expanded Chat window */}
      {isOpen && (
        <div className="w-80 sm:w-96 h-[450px] glass-panel rounded-3xl shadow-2xl flex flex-col overflow-hidden mb-4 animate-[fadeIn_0.2s_ease-out] border border-slate-200 dark:border-slate-800">
          
          {/* Header Banner */}
          <div className="bg-slate-900 text-white p-4 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Bot className="w-5 h-5 text-brand-400" />
              <div>
                <span className="font-bold text-sm block">Credit Assistant</span>
                <span className="text-[10px] text-emerald-400 font-semibold flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span> Online Sandbox Helper
                </span>
              </div>
            </div>
            <button 
              onClick={() => setIsOpen(false)}
              className="text-slate-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Messages list */}
          <div className="flex-1 p-4 overflow-y-auto space-y-4 bg-slate-50/50 dark:bg-navy-950/20">
            {messages.map((m) => (
              <div 
                key={m.id}
                className={`flex gap-2.5 max-w-[80%] ${m.sender === "user" ? "ml-auto flex-row-reverse" : ""}`}
              >
                <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                  m.sender === "user" 
                    ? "bg-brand-500 text-white" 
                    : "bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300"
                }`}>
                  {m.sender === "user" ? <User className="w-4.5 h-4.5" /> : <Bot className="w-4.5 h-4.5" />}
                </div>

                <div className="space-y-1">
                  <div className={`p-3 rounded-2xl text-xs leading-relaxed ${
                    m.sender === "user"
                      ? "bg-brand-500 text-white rounded-tr-none"
                      : "bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800/80 rounded-tl-none text-slate-800 dark:text-slate-200"
                  }`}>
                    {m.text.split("\n").map((line, i) => <p key={i}>{line}</p>)}
                  </div>
                  <span className="text-[9px] text-slate-400 block px-1 text-right">{m.time}</span>
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>

          {/* Quick FAQ Suggestion Bar */}
          <div className="px-4 py-2 bg-slate-100/50 dark:bg-slate-900/40 border-t border-slate-100 dark:border-slate-800/80 flex gap-2 overflow-x-auto whitespace-nowrap scrollbar-none">
            <button 
              onClick={() => setInput("How to improve credit score?")}
              className="text-[10px] font-semibold bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-full px-2.5 py-1 hover:text-brand-500 hover:border-brand-500 transition-colors"
            >
              Credit tips
            </button>
            <button 
              onClick={() => setInput("What is EMI calculation?")}
              className="text-[10px] font-semibold bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-full px-2.5 py-1 hover:text-brand-500 hover:border-brand-500 transition-colors"
            >
              EMI formula
            </button>
            <button 
              onClick={() => setInput("How does AI predict?")}
              className="text-[10px] font-semibold bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-full px-2.5 py-1 hover:text-brand-500 hover:border-brand-500 transition-colors"
            >
              AI details
            </button>
          </div>

          {/* Form Input */}
          <form onSubmit={handleSend} className="p-3 border-t border-slate-100 dark:border-slate-800/80 flex gap-2 bg-white dark:bg-slate-900">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask credit assistant..."
              className="flex-1 bg-slate-100 dark:bg-slate-800/50 rounded-xl px-4 py-2 text-xs border border-transparent focus:border-brand-500 focus:bg-white outline-none transition-all dark:text-white"
            />
            <button
              type="submit"
              className="w-9 h-9 rounded-xl bg-brand-500 hover:bg-brand-600 text-white flex items-center justify-center flex-shrink-0 transition-colors"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>

        </div>
      )}

      {/* Floating Action Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-14 h-14 rounded-full bg-brand-500 hover:bg-brand-600 text-white flex items-center justify-center shadow-lg shadow-brand-500/20 active:scale-[0.95] transition-all relative"
      >
        {isOpen ? <X className="w-6 h-6" /> : <MessageSquare className="w-6 h-6" />}
      </button>

    </div>
  );
}
