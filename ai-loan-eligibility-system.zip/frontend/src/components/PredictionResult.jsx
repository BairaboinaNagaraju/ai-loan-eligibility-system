import React, { useState } from "react";
import { jsPDF } from "jspdf";
import { 
  CheckCircle2, XCircle, Download, Mail, ArrowLeft, RefreshCw, 
  ChevronRight, AlertTriangle, ShieldCheck, FileText, Send
} from "lucide-react";

export default function PredictionResult({ result, formData, onReset, userName }) {
  const [emailInput, setEmailInput] = useState("");
  const [showEmailModal, setShowEmailModal] = useState(false);
  const [emailLoading, setEmailLoading] = useState(false);
  const [emailSuccess, setEmailSuccess] = useState(false);

  const { prediction, confidence_score, explanation, recommendations } = result;
  
  // Convert fractional confidence to percentage representation
  const confidencePercent = Math.round(confidence_score * 100);
  const isApproved = prediction === "Approved";

  // Dynamic SVG gauge coordinates
  const radius = 50;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (confidencePercent / 100) * circumference;

  const handleDownloadPDF = () => {
    const doc = new jsPDF({
      orientation: "portrait",
      unit: "mm",
      format: "a4"
    });

    // Premium PDF styling
    const brandColor = isApproved ? [16, 185, 129] : [239, 68, 68]; // Emerald vs Red
    
    // Header banner
    doc.setFillColor(30, 41, 59); // slate-800
    doc.rect(0, 0, 210, 35, "F");
    
    doc.setTextColor(255, 255, 255);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(22);
    doc.text("EliteBank AI Systems", 15, 22);
    
    doc.setFont("helvetica", "normal");
    doc.setFontSize(10);
    doc.setTextColor(203, 213, 225);
    doc.text("Credit Decision Sandbox & Explainable AI", 15, 29);

    // Document Title
    doc.setTextColor(15, 23, 42); // slate-900
    doc.setFont("helvetica", "bold");
    doc.setFontSize(16);
    doc.text("Official Loan Eligibility Decision Report", 15, 50);
    
    doc.setFont("helvetica", "normal");
    doc.setFontSize(10);
    doc.setTextColor(100, 116, 139);
    doc.text(`Generated on: ${new Date().toLocaleDateString()} | Applicant: ${userName || "Sandbox Client"}`, 15, 56);

    // Prediction Box
    doc.setFillColor(248, 250, 252); // slate-50
    doc.rect(15, 62, 180, 25, "F");
    doc.setDrawColor(226, 232, 240);
    doc.rect(15, 62, 180, 25);
    
    doc.setTextColor(brandColor[0], brandColor[1], brandColor[2]);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(14);
    doc.text(`AI STATUS: ${prediction.toUpperCase()}`, 25, 74);
    
    doc.setTextColor(71, 85, 105);
    doc.setFont("helvetica", "normal");
    doc.setFontSize(11);
    doc.text(`Confidence Probability: ${confidencePercent}%`, 25, 81);

    // Input Parameters Table
    doc.setTextColor(15, 23, 42);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(12);
    doc.text("Submitted Application Metrics", 15, 100);

    const inputs = [
      ["Applicant Monthly Income", `$${formData.applicant_income}`],
      ["Co-Applicant Monthly Income", `$${formData.coapplicant_income}`],
      ["Requested Loan Amount", `$${formData.loan_amount}k ($${formData.loan_amount * 1000})`],
      ["Repayment Tenure", `${formData.loan_amount_term} Days`],
      ["Credit History", formData.credit_history === 1 ? "Clean (1.0)" : "Poor (0.0)"],
      ["Property Location Area", formData.property_area],
      ["Education & Employment", `${formData.education} | Self Employed: ${formData.self_employed}`]
    ];

    let yPos = 108;
    doc.setFont("helvetica", "normal");
    doc.setFontSize(10);
    inputs.forEach(([label, val]) => {
      doc.setTextColor(100, 116, 139);
      doc.text(label, 15, yPos);
      doc.setTextColor(15, 23, 42);
      doc.text(val, 110, yPos);
      // Line separator
      doc.setDrawColor(241, 245, 249);
      doc.line(15, yPos + 2, 195, yPos + 2);
      yPos += 8;
    });

    // Explainable AI Details
    yPos += 6;
    doc.setFont("helvetica", "bold");
    doc.setFontSize(12);
    doc.text("AI Decision Explanation Factors", 15, yPos);
    yPos += 6;

    doc.setFont("helvetica", "normal");
    doc.setFontSize(9.5);
    doc.setTextColor(71, 85, 105);
    
    if (explanation && explanation.length > 0) {
      explanation.forEach((exp) => {
        // Handle line wrapping for long strings
        const splitText = doc.splitTextToSize(`- ${exp}`, 175);
        doc.text(splitText, 18, yPos);
        yPos += (splitText.length * 5);
      });
    } else {
      doc.text("- Standard metrics review applied.", 18, yPos);
      yPos += 6;
    }

    // Recommendations Details
    if (recommendations && recommendations.length > 0) {
      yPos += 4;
      doc.setFont("helvetica", "bold");
      doc.setFontSize(12);
      doc.setTextColor(15, 23, 42);
      doc.text("Actionable Recommendations to Improve Score", 15, yPos);
      yPos += 6;
      
      doc.setFont("helvetica", "normal");
      doc.setFontSize(9.5);
      doc.setTextColor(71, 85, 105);
      recommendations.forEach((rec) => {
        const splitText = doc.splitTextToSize(`- ${rec}`, 175);
        doc.text(splitText, 18, yPos);
        yPos += (splitText.length * 5);
      });
    }

    // Footer compliance notice
    yPos = Math.max(yPos + 10, 270);
    doc.setFont("helvetica", "italic");
    doc.setFontSize(7.5);
    doc.setTextColor(148, 163, 184);
    doc.text("EliteBank AI sandbox uses automated models. This evaluation is purely for advisory eligibility verification.", 15, yPos);
    
    doc.save(`EliteBank_AI_Report_${prediction}.pdf`);
  };

  const handleSendEmail = (e) => {
    e.preventDefault();
    if (!emailInput) return;
    
    setEmailLoading(true);
    // Simulate sending email api call
    setTimeout(() => {
      setEmailLoading(false);
      setEmailSuccess(true);
      setTimeout(() => {
        setShowEmailModal(false);
        setEmailSuccess(false);
        setEmailInput("");
      }, 2000);
    }, 1500);
  };

  return (
    <div className="w-full max-w-3xl mx-auto space-y-8 animate-[fadeIn_0.4s_ease-out]">
      {/* Outer Card */}
      <div className="glass-panel p-8 sm:p-12 rounded-3xl glow-primary relative overflow-hidden">
        {/* Header Ribbon Glow */}
        <div className={`absolute top-0 left-0 right-0 h-2 ${isApproved ? "bg-emerald-500" : "bg-red-500"}`}></div>

        <div className="flex flex-col md:flex-row items-center gap-10">
          
          {/* Left Arc/Gauge column */}
          <div className="flex flex-col items-center text-center space-y-4">
            <div className="relative w-40 h-40 flex items-center justify-center">
              {/* SVG circular gauge */}
              <svg className="w-full h-full transform -rotate-90" viewBox="0 0 120 120">
                <circle 
                  cx="60" 
                  cy="60" 
                  r="50" 
                  className="stroke-slate-200 dark:stroke-slate-800 fill-none" 
                  strokeWidth="8"
                />
                <circle 
                  cx="60" 
                  cy="60" 
                  r="50" 
                  className={`fill-none transition-all duration-1000 ${isApproved ? "stroke-emerald-500" : "stroke-red-500"}`}
                  strokeWidth="8"
                  strokeDasharray={circumference}
                  strokeDashoffset={strokeDashoffset}
                  strokeLinecap="round"
                />
              </svg>
              {/* Inner probability text */}
              <div className="absolute flex flex-col items-center">
                <span className="text-3xl font-extrabold">{confidencePercent}%</span>
                <span className="text-[10px] text-slate-400 uppercase font-bold tracking-wider">Confidence</span>
              </div>
            </div>

            <div className="space-y-1">
              <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold ${isApproved ? "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400" : "bg-red-500/10 text-red-600 dark:text-red-400"}`}>
                {isApproved ? (
                  <>
                    <CheckCircle2 className="w-4 h-4" /> Eligible
                  </>
                ) : (
                  <>
                    <XCircle className="w-4 h-4" /> Not Eligible
                  </>
                )}
              </span>
            </div>
          </div>

          {/* Right Explanation Column */}
          <div className="flex-1 space-y-6 w-full">
            <div>
              <h2 className="text-3xl font-extrabold leading-tight">
                Your application has been <span className={isApproved ? "text-emerald-500" : "text-red-500"}>{prediction}</span>
              </h2>
              <p className="text-sm text-slate-500 dark:text-slate-400 mt-1.5">
                Our model completed credit evaluation based on your personal and income metrics.
              </p>
            </div>

            {/* AI Explanation Reasons */}
            <div className="space-y-3">
              <h3 className="text-sm font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                <FileText className="w-4.5 h-4.5" /> AI Decision Criteria
              </h3>
              
              <div className="space-y-2">
                {explanation && explanation.length > 0 ? (
                  explanation.map((exp, idx) => (
                    <div key={idx} className="flex gap-2.5 items-start text-sm">
                      <ChevronRight className={`w-4 h-4 mt-0.5 flex-shrink-0 ${isApproved ? "text-emerald-500" : "text-red-500"}`} />
                      <p className="text-slate-600 dark:text-slate-300 leading-normal">{exp}</p>
                    </div>
                  ))
                ) : (
                  <p className="text-xs text-slate-400 italic">No detailed factors listed.</p>
                )}
              </div>
            </div>

            {/* AI Action Recommendations (Show always, even if approved, but critical if rejected) */}
            {recommendations && recommendations.length > 0 && (
              <div className="space-y-3 pt-4 border-t border-slate-100 dark:border-slate-800/80">
                <h3 className="text-sm font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                  <AlertTriangle className="w-4.5 h-4.5 text-amber-500" /> Actionable Recommendations
                </h3>
                <div className="space-y-2">
                  {recommendations.map((rec, idx) => (
                    <div key={idx} className="flex gap-2.5 items-start text-sm">
                      <CheckCircle2 className="w-4 h-4 mt-0.5 text-amber-500 flex-shrink-0" />
                      <p className="text-slate-600 dark:text-slate-300 leading-normal">{rec}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Action buttons row */}
            <div className="flex flex-wrap gap-4 pt-6">
              <button
                onClick={handleDownloadPDF}
                className="px-5 py-3 rounded-xl border border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800/50 transition-all font-bold text-sm flex items-center gap-1.5"
              >
                <Download className="w-4 h-4" /> Download PDF Report
              </button>

              <button
                onClick={() => setShowEmailModal(true)}
                className="px-5 py-3 rounded-xl border border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800/50 transition-all font-bold text-sm flex items-center gap-1.5"
              >
                <Mail className="w-4 h-4" /> Email Report
              </button>

              <button
                onClick={onReset}
                className="px-5 py-3 rounded-xl bg-brand-500 hover:bg-brand-600 text-white font-bold transition-all text-sm flex items-center gap-1.5 shadow-md shadow-brand-500/10 ml-auto"
              >
                <RefreshCw className="w-4 h-4" /> Apply Again
              </button>
            </div>

          </div>
        </div>
      </div>

      {/* Email Dispatch Modal */}
      {showEmailModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="w-full max-w-md glass-panel p-8 rounded-3xl glow-primary animate-[fadeIn_0.2s_ease-out]">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-lg font-bold">Email Prediction Report</h3>
              <button 
                onClick={() => setShowEmailModal(false)}
                className="w-8 h-8 rounded-full border border-slate-200 dark:border-slate-800 flex items-center justify-center hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400"
              >
                <XCircle className="w-5 h-5" />
              </button>
            </div>

            {emailSuccess ? (
              <div className="text-center py-6 space-y-3">
                <CheckCircle2 className="w-16 h-16 text-emerald-500 mx-auto" />
                <h4 className="text-xl font-bold">Report Dispatched!</h4>
                <p className="text-sm text-slate-500 dark:text-slate-400">
                  The PDF decision document has been emailed to <span className="font-bold">{emailInput}</span>.
                </p>
              </div>
            ) : (
              <form onSubmit={handleSendEmail} className="space-y-4">
                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-wider text-slate-400">Email Address</label>
                  <input
                    type="email"
                    value={emailInput}
                    onChange={(e) => setEmailInput(e.target.value)}
                    placeholder="Enter recipient's email"
                    className="w-full glass-input"
                    required
                  />
                </div>

                <button
                  type="submit"
                  disabled={emailLoading}
                  className="w-full py-3.5 rounded-xl bg-brand-500 hover:bg-brand-600 text-white font-bold transition-all shadow-md shadow-brand-500/10 flex items-center justify-center gap-2"
                >
                  {emailLoading ? "Sending..." : "Dispatch Email"} <Send className="w-4.5 h-4.5" />
                </button>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
