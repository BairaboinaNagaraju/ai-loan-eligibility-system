import React, { useState } from "react";
import { 
  User, CreditCard, DollarSign, ArrowRight, ArrowLeft, 
  HelpCircle, ShieldCheck, ClipboardCheck
} from "lucide-react";

export default function ApplicationForm({ onSubmit, loading }) {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    gender: "Male",
    married: "No",
    dependents: "0",
    education: "Graduate",
    self_employed: "No",
    applicant_income: "",
    coapplicant_income: "0",
    loan_amount: "",
    loan_amount_term: "360",
    credit_history: "1.0",
    property_area: "Semiurban"
  });

  const [errors, setErrors] = useState({});

  const validateStep = (currentStep) => {
    const newErrors = {};
    if (currentStep === 1) {
      if (!formData.gender) newErrors.gender = "Gender is required";
      if (!formData.married) newErrors.married = "Marital status is required";
      if (!formData.dependents) newErrors.dependents = "Dependents count is required";
      if (!formData.education) newErrors.education = "Education status is required";
      if (!formData.self_employed) newErrors.self_employed = "Employment status is required";
    }

    if (currentStep === 2) {
      const appInc = parseFloat(formData.applicant_income);
      if (isNaN(appInc) || appInc < 0) {
        newErrors.applicant_income = "Applicant income must be a positive number";
      } else if (appInc === 0) {
        newErrors.applicant_income = "Income must be greater than zero";
      }
      
      const coInc = parseFloat(formData.coapplicant_income);
      if (isNaN(coInc) || coInc < 0) {
        newErrors.coapplicant_income = "Co-applicant income must be a positive number";
      }
      
      if (!formData.credit_history) newErrors.credit_history = "Credit history verification is required";
    }

    if (currentStep === 3) {
      const loanAmt = parseFloat(formData.loan_amount);
      if (isNaN(loanAmt) || loanAmt <= 0) {
        newErrors.loan_amount = "Loan amount must be greater than 0";
      }
      
      const term = parseFloat(formData.loan_amount_term);
      if (isNaN(term) || term <= 0) {
        newErrors.loan_amount_term = "Loan term must be greater than 0";
      }
      
      if (!formData.property_area) newErrors.property_area = "Property area selection is required";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleNext = () => {
    if (validateStep(step)) {
      setStep(step + 1);
    }
  };

  const handleBack = () => {
    setStep(step - 1);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    // Clear error
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: "" }));
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (validateStep(3)) {
      // Convert numeric fields to numbers
      const formattedData = {
        ...formData,
        applicant_income: parseFloat(formData.applicant_income),
        coapplicant_income: parseFloat(formData.coapplicant_income),
        loan_amount: parseFloat(formData.loan_amount),
        loan_amount_term: parseFloat(formData.loan_amount_term),
        credit_history: parseFloat(formData.credit_history)
      };
      onSubmit(formattedData);
    }
  };

  return (
    <div className="w-full max-w-2xl mx-auto glass-panel p-8 rounded-3xl glow-primary">
      {/* Progress Header */}
      <div className="flex justify-between items-center mb-8 border-b border-slate-100 dark:border-slate-800/80 pb-4">
        <div>
          <h3 className="text-xl font-bold flex items-center gap-2">
            <ClipboardCheck className="w-6 h-6 text-brand-500" /> Loan Application Sandbox
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">Provide your metrics to run prediction</p>
        </div>
        <div className="text-sm font-semibold text-slate-500 bg-slate-100 dark:bg-slate-900 px-3 py-1.5 rounded-xl">
          Step {step} of 3
        </div>
      </div>

      {/* Progress Bar */}
      <div className="w-full bg-slate-100 dark:bg-slate-800 h-1.5 rounded-full mb-8 overflow-hidden">
        <div 
          className="bg-brand-500 h-full transition-all duration-300"
          style={{ width: `${(step / 3) * 100}%` }}
        ></div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* STEP 1: Personal Profile */}
        {step === 1 && (
          <div className="space-y-5 animate-[fadeIn_0.3s_ease-out]">
            <h4 className="text-sm font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5 mb-2">
              <User className="w-4 h-4" /> 1. Personal & Professional Profile
            </h4>
            
            <div className="grid sm:grid-cols-2 gap-5">
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-500 dark:text-slate-400">Gender</label>
                <select 
                  name="gender" 
                  value={formData.gender} 
                  onChange={handleChange}
                  className="w-full glass-input"
                >
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-500 dark:text-slate-400">Married</label>
                <select 
                  name="married" 
                  value={formData.married} 
                  onChange={handleChange}
                  className="w-full glass-input"
                >
                  <option value="No">No</option>
                  <option value="Yes">Yes</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-500 dark:text-slate-400">Dependents</label>
                <select 
                  name="dependents" 
                  value={formData.dependents} 
                  onChange={handleChange}
                  className="w-full glass-input"
                >
                  <option value="0">0 Dependents</option>
                  <option value="1">1 Dependent</option>
                  <option value="2">2 Dependents</option>
                  <option value="3+">3 or More (3+)</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-500 dark:text-slate-400">Education</label>
                <select 
                  name="education" 
                  value={formData.education} 
                  onChange={handleChange}
                  className="w-full glass-input"
                >
                  <option value="Graduate">Graduate (University Degree)</option>
                  <option value="Not Graduate">Not Graduate (No Degree)</option>
                </select>
              </div>

              <div className="space-y-1 sm:col-span-2">
                <label className="text-xs font-semibold text-slate-500 dark:text-slate-400">Self-Employed Status</label>
                <select 
                  name="self_employed" 
                  value={formData.self_employed} 
                  onChange={handleChange}
                  className="w-full glass-input"
                >
                  <option value="No">No (Salaried Employee)</option>
                  <option value="Yes">Yes (Independent Business Owners/Freelancer)</option>
                </select>
              </div>
            </div>
          </div>
        )}

        {/* STEP 2: Financial Details */}
        {step === 2 && (
          <div className="space-y-5 animate-[fadeIn_0.3s_ease-out]">
            <h4 className="text-sm font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5 mb-2">
              <CreditCard className="w-4 h-4" /> 2. Financial Metrics
            </h4>

            <div className="space-y-4">
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-500 dark:text-slate-400">Applicant Monthly Income ($)</label>
                <div className="relative">
                  <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400">
                    <DollarSign className="w-4 h-4" />
                  </span>
                  <input
                    type="number"
                    name="applicant_income"
                    value={formData.applicant_income}
                    onChange={handleChange}
                    placeholder="e.g. 5000"
                    className={`w-full glass-input pl-11 ${errors.applicant_income ? "border-red-500" : ""}`}
                    required
                  />
                </div>
                {errors.applicant_income && (
                  <p className="text-xs text-red-500 font-medium">{errors.applicant_income}</p>
                )}
              </div>

              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-500 dark:text-slate-400">Co-Applicant Monthly Income ($) (Enter 0 if none)</label>
                <div className="relative">
                  <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400">
                    <DollarSign className="w-4 h-4" />
                  </span>
                  <input
                    type="number"
                    name="coapplicant_income"
                    value={formData.coapplicant_income}
                    onChange={handleChange}
                    placeholder="e.g. 2000"
                    className={`w-full glass-input pl-11 ${errors.coapplicant_income ? "border-red-500" : ""}`}
                    required
                  />
                </div>
                {errors.coapplicant_income && (
                  <p className="text-xs text-red-500 font-medium">{errors.coapplicant_income}</p>
                )}
              </div>

              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-500 dark:text-slate-400">Credit History Record</label>
                <select 
                  name="credit_history" 
                  value={formData.credit_history} 
                  onChange={handleChange}
                  className="w-full glass-input"
                >
                  <option value="1.0">Clean Credit History (No defaults, regular payments)</option>
                  <option value="0.0">Poor Credit History (Prior payment failures, active defaults)</option>
                </select>
              </div>
            </div>
          </div>
        )}

        {/* STEP 3: Loan Details */}
        {step === 3 && (
          <div className="space-y-5 animate-[fadeIn_0.3s_ease-out]">
            <h4 className="text-sm font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5 mb-2">
              <DollarSign className="w-4 h-4" /> 3. Loan Requirements & Property Details
            </h4>

            <div className="grid sm:grid-cols-2 gap-5">
              <div className="space-y-1 sm:col-span-2">
                <label className="text-xs font-semibold text-slate-500 dark:text-slate-400">Requested Loan Amount (in Thousands $)</label>
                <div className="relative">
                  <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400">
                    <DollarSign className="w-4 h-4" />
                  </span>
                  <input
                    type="number"
                    name="loan_amount"
                    value={formData.loan_amount}
                    onChange={handleChange}
                    placeholder="e.g. 150 (for $150,000)"
                    className={`w-full glass-input pl-11 ${errors.loan_amount ? "border-red-500" : ""}`}
                    required
                  />
                </div>
                {errors.loan_amount && (
                  <p className="text-xs text-red-500 font-medium">{errors.loan_amount}</p>
                )}
                <p className="text-[10px] text-slate-400 mt-1">Note: Enter 150 to request $150,000.</p>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-500 dark:text-slate-400">Loan Term (in Days)</label>
                <select 
                  name="loan_amount_term" 
                  value={formData.loan_amount_term} 
                  onChange={handleChange}
                  className="w-full glass-input"
                >
                  <option value="120">120 Days (4 Months)</option>
                  <option value="180">180 Days (6 Months)</option>
                  <option value="240">240 Days (8 Months)</option>
                  <option value="360">360 Days (12 Months / 1 Year)</option>
                  <option value="480">480 Days (16 Months)</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-500 dark:text-slate-400">Property Area Setting</label>
                <select 
                  name="property_area" 
                  value={formData.property_area} 
                  onChange={handleChange}
                  className="w-full glass-input"
                >
                  <option value="Urban">Urban (City Center)</option>
                  <option value="Semiurban">Semi-Urban (Suburbs)</option>
                  <option value="Rural">Rural (Countryside)</option>
                </select>
              </div>
            </div>
          </div>
        )}

        {/* Buttons Row */}
        <div className="flex justify-between items-center pt-6 border-t border-slate-100 dark:border-slate-800/80">
          {step > 1 ? (
            <button
              type="button"
              onClick={handleBack}
              className="px-6 py-3 rounded-xl border border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800/50 transition-all text-sm font-bold flex items-center gap-1.5"
            >
              <ArrowLeft className="w-4 h-4" /> Back
            </button>
          ) : (
            <div></div> // Spacing placeholder
          )}

          {step < 3 ? (
            <button
              type="button"
              onClick={handleNext}
              className="px-6 py-3 rounded-xl bg-brand-500 hover:bg-brand-600 text-white font-bold transition-all flex items-center gap-1.5 shadow-md shadow-brand-500/10 text-sm"
            >
              Continue <ArrowRight className="w-4 h-4" />
            </button>
          ) : (
            <button
              type="submit"
              disabled={loading}
              className="px-8 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-600 active:scale-[0.99] text-white font-bold transition-all flex items-center gap-1.5 shadow-md shadow-emerald-500/10 text-sm disabled:opacity-50"
            >
              {loading ? (
                "Analyzing Credit Metrics..."
              ) : (
                <>
                  Submit Application <ShieldCheck className="w-4 h-4" />
                </>
              )}
            </button>
          )}
        </div>
      </form>
    </div>
  );
}
